@tool
extends MarginContainer

# Store the config inside my_tools/bookmarks folder so Git can track and sync it seamlessly
const SAVE_PATH = "res://addons/my_tools/bookmarks/my_editor_bookmarks.cfg"

var plugin: EditorPlugin
var list_container: VBoxContainer

# Handle drag & drop events inside the Bookmarks dock
func _can_drop_data(_at_position: Vector2, data: Variant) -> bool:
	if data is Dictionary and data.has("type") and data["type"] == "files":
		var files = data["files"]
		if files is Array:
			for f in files:
				# Only accept .tscn scene files
				if str(f).ends_with(".tscn"):
					return true
	return false
	
func _drop_data(_at_position: Vector2, data: Variant) -> void:
	if data is Dictionary and data.has("files"):
		var files = data["files"]
		var bookmarks: Array[String] = _load_bookmarks()
		var changed: bool = false
		
		for f in files:
			var path: String = str(f)
			if path.ends_with(".tscn") and not bookmarks.has(path):
				bookmarks.append(path)
				changed = true
				
		if changed:
			_save_bookmarks(bookmarks)
			_refresh_bookmark_list()

# Setup the Dock interface (called from the main my_addons_main.gd plugin)
func setup_dock(p_plugin: EditorPlugin) -> void:
	plugin = p_plugin
	name = "Bookmarks"
	
	# Set margins and spacing
	var margin_val: int = 8
	add_theme_constant_override("margin_top", margin_val)
	add_theme_constant_override("margin_bottom", margin_val)
	add_theme_constant_override("margin_left", margin_val)
	add_theme_constant_override("margin_right", margin_val)
	
	var scroll: ScrollContainer = ScrollContainer.new()
	scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	add_child(scroll)
	
	var vbox: VBoxContainer = VBoxContainer.new()
	vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	vbox.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.add_child(vbox)
	
	# Title label
	var title_label: Label = Label.new()
	title_label.text = "QUICK BOOKMARKS"
	title_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(title_label)
	
	# Horizontal toolbar
	var toolbar: HBoxContainer = HBoxContainer.new()
	vbox.add_child(toolbar)
	
	# Action Button 1: Pin Current Scene
	var pin_current_btn: Button = Button.new()
	pin_current_btn.text = "Pin Current Scene"
	pin_current_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var editor_base: Control = plugin.get_editor_interface().get_base_control()
	if editor_base:
		pin_current_btn.icon = editor_base.get_theme_icon("Pin", "EditorIcons")
	pin_current_btn.pressed.connect(_on_bookmark_current_pressed)
	toolbar.add_child(pin_current_btn)
	
	# Action Button 2: Help
	var help_btn: Button = Button.new()
	help_btn.text = "Help"
	help_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	if editor_base:
		help_btn.icon = editor_base.get_theme_icon("Help", "EditorIcons")
	help_btn.pressed.connect(_on_help_btn_pressed)
	toolbar.add_child(help_btn)
	
	var sep: HSeparator = HSeparator.new()
	vbox.add_child(sep)
	
	# Container for dynamic rows
	list_container = VBoxContainer.new()
	list_container.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	list_container.size_flags_vertical = Control.SIZE_EXPAND_FILL
	vbox.add_child(list_container)
	
	# Initial rendering
	_refresh_bookmark_list()

# Handles pinning the active open scene in the editor
func _on_bookmark_current_pressed() -> void:
	var root: Node = plugin.get_editor_interface().get_edited_scene_root()
	if not root:
		print_rich("[color=yellow][Bookmarks] No active scene is open to pin![/color]")
		return
		
	var path: String = root.scene_file_path
	if path == "":
		print_rich("[color=yellow][Bookmarks] This scene is unsaved! Please save the scene before pinning.[/color]")
		return
		
	var bookmarks: Array[String] = _load_bookmarks()
	if not bookmarks.has(path):
		bookmarks.append(path)
		_save_bookmarks(bookmarks)
		_refresh_bookmark_list()
		print_rich("[color=green][Bookmarks] Successfully pinned: %s[/color]" % [path])
	else:
		print("[Bookmarks] This scene is already pinned!")

# Pop up help dialog instructions
func _on_help_btn_pressed() -> void:
	var dialog: AcceptDialog = AcceptDialog.new()
	dialog.title = "Bookmarks Instructions"
	dialog.dialog_text = "How to use this tool:\n\n" + \
		"1. Click 'Pin Current Scene' to quickly bookmark the active open scene in your editor.\n\n" + \
		"2. Alternatively, you can drag-and-drop any '.tscn' file directly from the FileSystem tab into this dock to pin it instantly.\n\n" + \
		"3. Click any pinned scene button to open it immediately in the editor.\n\n" + \
		"4. Click the '-' button next to any scene to remove its bookmark."
		
	plugin.get_editor_interface().get_base_control().add_child(dialog)
	dialog.popup_centered(Vector2(450, 280))
	dialog.visibility_changed.connect(func(): if not dialog.visible: dialog.queue_free())

# Refresh the dynamic list UI
func _refresh_bookmark_list() -> void:
	if not list_container:
		return
		
	# Clear old items
	for child in list_container.get_children():
		child.queue_free()
		
	var bookmarks: Array[String] = _load_bookmarks()
	var editor_base: Control = plugin.get_editor_interface().get_base_control()
	
	# Empty state
	if bookmarks.is_empty():
		var empty_label: Label = Label.new()
		empty_label.text = "No scenes pinned yet.\n(Click 'Pin Current Scene' or drag-and-drop any .tscn file from the FileSystem here)"
		empty_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		empty_label.autowrap_mode = TextServer.AUTOWRAP_WORD
		empty_label.modulate = Color(0.6, 0.6, 0.6)
		list_container.add_child(empty_label)
		return
		
	# Render rows
	for path in bookmarks:
		var hbox: HBoxContainer = HBoxContainer.new()
		list_container.add_child(hbox)
		
		var open_btn: Button = Button.new()
		open_btn.text = path.get_file()
		if editor_base:
			open_btn.icon = editor_base.get_theme_icon("PackedScene", "EditorIcons")
		open_btn.alignment = HORIZONTAL_ALIGNMENT_LEFT
		open_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		open_btn.tooltip_text = path
		open_btn.pressed.connect(_open_scene.bind(path))
		hbox.add_child(open_btn)
		
		var remove_btn: Button = Button.new()
		if editor_base:
			remove_btn.icon = editor_base.get_theme_icon("Remove", "EditorIcons")
		remove_btn.tooltip_text = "Remove pin"
		remove_btn.pressed.connect(_remove_bookmark.bind(path))
		hbox.add_child(remove_btn)

# Handles opening the pinned scene file
func _open_scene(path: String) -> void:
	if FileAccess.file_exists(path):
		plugin.get_editor_interface().open_scene_from_path(path)
		print("[Bookmarks] Opened: ", path)
	else:
		print_rich("[color=red][Bookmarks] File not found, automatically unpinning: %s[/color]" % [path])
		_remove_bookmark(path)

# Handles unpinning a scene
func _remove_bookmark(path: String) -> void:
	var bookmarks: Array[String] = _load_bookmarks()
	if bookmarks.has(path):
		bookmarks.erase(path)
		_save_bookmarks(bookmarks)
		_refresh_bookmark_list()

# --- PERSISTENT STORAGE WRITE (ConfigFile) ---
func _save_bookmarks(bookmarks: Array[String]) -> void:
	var config: ConfigFile = ConfigFile.new()
	config.set_value("bookmarks", "paths", bookmarks)
	
	var dir_path: String = SAVE_PATH.get_base_dir()
	if not DirAccess.dir_exists_absolute(dir_path):
		DirAccess.make_dir_recursive_absolute(dir_path)
		
	config.save(SAVE_PATH)

# --- PERSISTENT STORAGE READ ---
func _load_bookmarks() -> Array[String]:
	var bookmarks: Array[String] = []
	var config: ConfigFile = ConfigFile.new()
	
	if config.load(SAVE_PATH) == OK:
		var loaded_data = config.get_value("bookmarks", "paths", [])
		if loaded_data is Array:
			for item in loaded_data:
				if item is String:
					bookmarks.append(item)
	return bookmarks

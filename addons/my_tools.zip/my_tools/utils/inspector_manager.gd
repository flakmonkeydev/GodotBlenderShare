@tool
extends RefCounted

var plugin: EditorPlugin
var ins_collapse_btn: Button
var ins_expand_btn: Button

# SỬA LỖI BIÊN DỊCH: Sử dụng kiểu Object để phá vỡ vòng lặp biên dịch tĩnh lúc khởi động
func _init(p_plugin: Object) -> void:
	plugin = p_plugin as EditorPlugin

# Automatically inject Collapse/Expand buttons into the Inspector toolbar
func inject_buttons() -> void:
	var editor_interface: EditorInterface = plugin.get_editor_interface()
	var inspector: EditorInspector = editor_interface.get_inspector()
	var editor_base: Control = editor_interface.get_base_control()
	if not inspector or not editor_base:
		return
		
	var parent_dock: Node = inspector.get_parent()
	if not parent_dock:
		return
		
	# CHỐNG TRÙNG LẶP SỚM: Nếu nút đã được chèn rồi thì bỏ qua ngay để tránh giật lag UI
	if parent_dock.find_child("CustomInspectorCollapse", true, false) != null:
		return
		
	# Quét dọn sạch sẽ toàn bộ các nút cũ bị trùng lặp trong cụm Inspector
	# Quét từ lề ngoài cùng của cụm Inspector (lên tới 4 cấp cha) để dọn sạch rác triệt để
	var current_node: Node = inspector
	for i in range(4):
		if current_node == null:
			break
		current_node = current_node.get_parent()
		if current_node:
			_remove_orphaned_buttons_recursive(current_node, "CustomInspector")
			
	var back_icon = editor_base.get_theme_icon("Back", "EditorIcons")
	
	# Tìm kiếm nút Back bằng thuật toán xích cha đệ quy
	var back_btn: Button = null
	current_node = inspector
	for i in range(4):
		if current_node == null:
			break
		current_node = current_node.get_parent()
		if current_node:
			back_btn = _find_back_button(current_node, back_icon)
			if back_btn:
				break # Đã tìm thấy nút Back!
				
	if back_btn:
		var parent_toolbar: Node = back_btn.get_parent()
		var idx: int = back_btn.get_index()
		
		# Khởi tạo nút Collapse
		ins_collapse_btn = Button.new()
		ins_collapse_btn.name = "CustomInspectorCollapse"
		ins_collapse_btn.flat = true
		ins_collapse_btn.tooltip_text = "Collapse All Inspector Groups"
		ins_collapse_btn.icon = editor_base.get_theme_icon("CollapseTree", "EditorIcons") as Texture2D
		if not ins_collapse_btn.icon:
			ins_collapse_btn.text = "Col"
		ins_collapse_btn.pressed.connect(_on_inspector_collapse_pressed)
		
		# Khởi tạo nút Expand
		ins_expand_btn = Button.new()
		ins_expand_btn.name = "CustomInspectorExpand"
		ins_expand_btn.flat = true
		ins_expand_btn.tooltip_text = "Expand All Inspector Groups"
		ins_expand_btn.icon = editor_base.get_theme_icon("ExpandTree", "EditorIcons") as Texture2D
		if not ins_expand_btn.icon:
			ins_expand_btn.text = "Exp"
		ins_expand_btn.pressed.connect(_on_inspector_expand_pressed)
		
		# Chèn 2 nút phẳng mới vào ngay trước nút Back (<)
		parent_toolbar.add_child(ins_collapse_btn)
		parent_toolbar.move_child(ins_collapse_btn, idx)
		
		parent_toolbar.add_child(ins_expand_btn)
		parent_toolbar.move_child(ins_expand_btn, idx + 1)
		
		print("[Inspector] Successfully injected Collapse & Expand buttons to the toolbar!")
	else:
		print("[Inspector Warning] Could not find the native Back button (<) on the Inspector toolbar. (Make sure a Node is selected in the Scene Tree).")

# Free buttons from memory when disabling the plugin
func cleanup() -> void:
	if ins_collapse_btn and is_instance_valid(ins_collapse_btn):
		ins_collapse_btn.queue_free()
	if ins_expand_btn and is_instance_valid(ins_expand_btn):
		ins_expand_btn.queue_free()
		
	var editor_interface: EditorInterface = plugin.get_editor_interface()
	var inspector: EditorInspector = editor_interface.get_inspector()
	if inspector:
		# Dọn dẹp sạch rác cũ lên tới 4 cấp cha liên tiếp
		var current_node: Node = inspector
		for i in range(4):
			if current_node == null:
				break
			current_node = current_node.get_parent()
			if current_node:
				_remove_orphaned_buttons_recursive(current_node, "CustomInspector")

# Tìm kiếm nút Back bằng cách đối chiếu cả Icon, Tooltip đa ngôn ngữ lẫn tên Node
func _find_back_button(node: Node, back_icon) -> Button:
	if node is Button:
		if back_icon != null and node.icon == back_icon:
			return node
		var tooltip: String = node.tooltip_text.to_lower()
		if "previous" in tooltip or "prev" in tooltip or "trước" in tooltip or "quay lại" in tooltip:
			return node
		if "back" in node.name.to_lower():
			return node
			
	for child in node.get_children():
		var found: Button = _find_back_button(child, back_icon)
		if found:
			return found
	return null

# Giải phóng tức thời các nút cũ bằng free() để dọn bộ đệm ngay lập tức
func _remove_orphaned_buttons_recursive(node: Node, prefix: String) -> void:
	for child in node.get_children():
		if child is Button and child.name.begins_with(prefix):
			child.free()
		else:
			_remove_orphaned_buttons_recursive(child, prefix)

# =============================================================================
# LOGIC CO GIÃN CÁC NHÓM THUỘC TÍNH @EXPORT (SỬ DỤNG GIẢ LẬP CLICK QUA VIEWPORT)
# =============================================================================

# Hàm đệ quy tìm kiếm tất cả các Node EditorInspectorSection (nhóm export) trong Inspector
func _find_sections_recursive(node: Node, list: Array[Node]) -> void:
	if node.get_class() == "EditorInspectorSection":
		list.append(node)
	for child in node.get_children():
		_find_sections_recursive(child, list)

# Thu gọn toàn bộ các nhóm export (Bơm click qua Viewport nếu chiều cao đang mở rộng > 35px)
func _on_inspector_collapse_pressed() -> void:
	var editor_interface: EditorInterface = plugin.get_editor_interface()
	var inspector: EditorInspector = editor_interface.get_inspector()
	if inspector:
		var sections: Array[Node] = []
		_find_sections_recursive(inspector, sections)
		
		for section in sections:
			if section is Control:
				# Nếu chiều cao dọc > 35px nghĩa là nhóm đang mở rộng, tiến hành click chuột ảo để thu gọn
				if section.size.y > 35:
					_simulate_click_on_control(section)
					
		print("[Inspector] Collapsed all export groups.")

# Mở rộng toàn bộ các nhóm export (Bơm click qua Viewport nếu chiều cao đang thu gọn <= 35px)
func _on_inspector_expand_pressed() -> void:
	var editor_interface: EditorInterface = plugin.get_editor_interface()
	var inspector: EditorInspector = editor_interface.get_inspector()
	if inspector:
		var sections: Array[Node] = []
		_find_sections_recursive(inspector, sections)
		
		for section in sections:
			if section is Control:
				# Nếu chiều cao dọc <= 35px nghĩa là nhóm đang thu gọn, tiến hành click chuột ảo để mở rộng
				if section.size.y <= 35:
					_simulate_click_on_control(section)
					
		print("[Inspector] Expanded all export groups.")

# Hàm giả lập click chuột trái vào một Control Node bằng cách bơm sự kiện qua Viewport (MỚI - SỬA LỖI)
func _simulate_click_on_control(control: Control) -> void:
	var ev: InputEventMouseButton = InputEventMouseButton.new()
	ev.button_index = MOUSE_BUTTON_LEFT
	
	# Tính toán vị trí click chuột ảo chính xác tuyệt đối trên màn hình Editor
	# (Click vào góc trên bên trái của thanh tiêu đề Group, cách lề trái 15px, lề trên 10px)
	ev.global_position = control.global_position + Vector2(15, 10)
	ev.position = ev.global_position
	
	# Gửi sự kiện nhấn chuột xuống (Pressed) qua Viewport của Editor
	ev.pressed = true
	control.get_viewport().push_input(ev)
	
	# Gửi sự kiện nhả chuột ra (Released) qua Viewport của Editor
	ev.pressed = false
	control.get_viewport().push_input(ev)

@tool
extends RefCounted

var plugin: EditorPlugin
var fs_toolbar: HBoxContainer
var fs_collapse_btn: Button
var fs_collapse_sel_btn: Button
var fs_expand_sel_btn: Button
var fs_expand_dir_btn: Button

# SỬA LỖI PHÒNG NGỪA: Sử dụng kiểu Object để phá vỡ vòng lặp biên dịch
func _init(p_plugin: Object) -> void:
	plugin = p_plugin as EditorPlugin

# Tự động chèn nút vào thanh công cụ FileSystem Dock
func inject_buttons() -> void:
	var editor_interface: EditorInterface = plugin.get_editor_interface()
	var fs_dock: FileSystemDock = editor_interface.get_file_system_dock()
	var editor_base: Control = editor_interface.get_base_control()
	if not fs_dock or not editor_base:
		return
		
	# QUAN TRỌNG: Quét sạch mọi nút trùng lặp/rác cũ trước khi chèn mới
	_remove_orphaned_buttons_recursive(fs_dock, "CustomFileSystem")
	
	# Ép kiểu tĩnh về Control để tương thích tuyệt đối mọi phiên bản Godot 4
	var target_hbox: Control = _get_filesystem_search_hbox() as Control
	if not target_hbox:
		target_hbox = fs_dock as Control
		
	# 1. Nút Collapse All under res://
	fs_collapse_btn = Button.new()
	fs_collapse_btn.name = "CustomFileSystemCollapse"
	fs_collapse_btn.flat = true
	fs_collapse_btn.tooltip_text = "Collapse all folders under res://"
	fs_collapse_btn.icon = editor_base.get_theme_icon("CollapseTree", "EditorIcons") as Texture2D
	if not fs_collapse_btn.icon:
		fs_collapse_btn.text = "Col All"
	fs_collapse_btn.pressed.connect(_on_fs_collapse_pressed)
	target_hbox.add_child(fs_collapse_btn)
	
	# 2. Nút Collapse Selected
	fs_collapse_sel_btn = Button.new()
	fs_collapse_sel_btn.name = "CustomFileSystemCollapseSel"
	fs_collapse_sel_btn.flat = true
	fs_collapse_sel_btn.tooltip_text = "Collapse selected folder and all its descendants"
	fs_collapse_sel_btn.icon = editor_base.get_theme_icon("CollapseTree", "EditorIcons") as Texture2D
	if not fs_collapse_sel_btn.icon:
		fs_collapse_sel_btn.text = "Col Sel"
	fs_collapse_sel_btn.pressed.connect(_on_fs_collapse_sel_pressed)
	target_hbox.add_child(fs_collapse_sel_btn)
	
	# 3. Nút Expand Selected
	fs_expand_sel_btn = Button.new()
	fs_expand_sel_btn.name = "CustomFileSystemExpandSel"
	fs_expand_sel_btn.flat = true
	fs_expand_sel_btn.tooltip_text = "Expand selected folder and all its descendants"
	fs_expand_sel_btn.icon = editor_base.get_theme_icon("Folder", "EditorIcons") as Texture2D
	if not fs_expand_sel_btn.icon:
		fs_expand_sel_btn.text = "Exp Sel"
	fs_expand_sel_btn.pressed.connect(_on_fs_expand_sel_pressed)
	target_hbox.add_child(fs_expand_sel_btn)
	
	# 4. Nút Expand Direct Only
	fs_expand_dir_btn = Button.new()
	fs_expand_dir_btn.name = "CustomFileSystemExpandDir"
	fs_expand_dir_btn.flat = true
	fs_expand_dir_btn.tooltip_text = "Expand selected folder and its direct children only"
	fs_expand_dir_btn.icon = editor_base.get_theme_icon("Tree", "EditorIcons") as Texture2D
	if not fs_expand_dir_btn.icon:
		fs_expand_dir_btn.text = "Exp Dir"
	fs_expand_dir_btn.pressed.connect(_on_fs_expand_dir_pressed)
	target_hbox.add_child(fs_expand_dir_btn)
	
	if target_hbox == fs_dock:
		fs_toolbar = HBoxContainer.new()
		fs_toolbar.name = "CustomFileSystemToolbar"
		fs_dock.add_child(fs_toolbar)
		fs_dock.move_child(fs_toolbar, 0)
		
		target_hbox.remove_child(fs_collapse_btn)
		target_hbox.remove_child(fs_collapse_sel_btn)
		target_hbox.remove_child(fs_expand_sel_btn)
		target_hbox.remove_child(fs_expand_dir_btn)
		
		fs_toolbar.add_child(fs_collapse_btn)
		fs_toolbar.add_child(fs_collapse_sel_btn)
		fs_toolbar.add_child(fs_expand_sel_btn)
		fs_toolbar.add_child(fs_expand_dir_btn)

# Dọn dẹp nút bấm khi tắt plugin
func cleanup() -> void:
	if fs_toolbar and is_instance_valid(fs_toolbar):
		fs_toolbar.queue_free()
	if fs_collapse_btn and is_instance_valid(fs_collapse_btn):
		fs_collapse_btn.queue_free()
	if fs_collapse_sel_btn and is_instance_valid(fs_collapse_sel_btn):
		fs_collapse_sel_btn.queue_free()
	if fs_expand_sel_btn and is_instance_valid(fs_expand_sel_btn):
		fs_expand_sel_btn.queue_free()
	if fs_expand_dir_btn and is_instance_valid(fs_expand_dir_btn):
		fs_expand_dir_btn.queue_free()
		
	var editor_interface: EditorInterface = plugin.get_editor_interface()
	var fs_dock: FileSystemDock = editor_interface.get_file_system_dock()
	if fs_dock:
		_remove_orphaned_buttons_recursive(fs_dock, "CustomFileSystem")

func _remove_orphaned_buttons_recursive(node: Node, prefix: String) -> void:
	for child in node.get_children():
		if child is Button and child.name.begins_with(prefix):
			child.free()
		elif child is HBoxContainer and child.name.begins_with(prefix):
			child.free()
		else:
			_remove_orphaned_buttons_recursive(child, prefix)

func _get_filesystem_search_hbox() -> HBoxContainer:
	var editor_interface: EditorInterface = plugin.get_editor_interface()
	var fs_dock: FileSystemDock = editor_interface.get_file_system_dock()
	if not fs_dock:
		return null
		
	var hboxes: Array[Node] = fs_dock.find_children("*", "HBoxContainer", true, false)
	for hbox in hboxes:
		var line_edits: Array[Node] = hbox.find_children("*", "LineEdit", true, false)
		for le in line_edits:
			if le is LineEdit and not le.text.begins_with("res://"):
				return hbox as HBoxContainer
	return null

func _get_filesystem_tree() -> Tree:
	var editor_interface: EditorInterface = plugin.get_editor_interface()
	var fs_dock: FileSystemDock = editor_interface.get_file_system_dock()
	if not fs_dock:
		return null
	var trees: Array[Node] = fs_dock.find_children("*", "Tree", true, false)
	if not trees.is_empty():
		return trees[0] as Tree
	return null

func _on_fs_collapse_pressed() -> void:
	var tree: Tree = _get_filesystem_tree()
	if tree:
		var root: TreeItem = tree.get_root()
		if root:
			_collapse_subfolders_of_root(root)

# Thu gọn mục đang chọn
func _on_fs_collapse_sel_pressed() -> void:
	var tree: Tree = _get_filesystem_tree()
	if tree:
		var selected: TreeItem = tree.get_selected()
		if selected:
			_set_collapsed_recursive(selected, true)

func _on_fs_expand_sel_pressed() -> void:
	var tree: Tree = _get_filesystem_tree()
	if tree:
		var selected: TreeItem = tree.get_selected()
		if selected:
			_set_collapsed_recursive(selected, false)

func _on_fs_expand_dir_pressed() -> void:
	var tree: Tree = _get_filesystem_tree()
	if tree:
		var selected: TreeItem = tree.get_selected()
		if selected:
			# Đệ quy bắt đầu từ thư mục chọn (mức 0) mở rộng, con của nó (mức 1) mở rộng, cháu (mức 2+) tự thu gọn
			_set_collapsed_depth_limit(selected, 0, 2)

# --- CÁC HÀM ĐỆ QUY HỖ TRỢ XỬ LÝ TREEITEM ---

# Thu gọn toàn bộ thư mục con của res:// nhưng giữ lại res:// mở rộng
func _collapse_subfolders_of_root(root: TreeItem) -> void:
	if not root:
		return
	root.set_collapsed(false)
	
	var child: TreeItem = root.get_first_child()
	while child:
		_set_collapsed_recursive(child, true)
		child = child.get_next()

# Đệ quy thu gọn/mở rộng không giới hạn
func _set_collapsed_recursive(item: TreeItem, collapsed: bool) -> void:
	if not item:
		return
	item.set_collapsed(collapsed)
	
	var child: TreeItem = item.get_first_child()
	while child:
		_set_collapsed_recursive(child, collapsed)
		child = child.get_next()

# Đệ quy thu gọn/mở rộng giới hạn độ sâu
func _set_collapsed_depth_limit(item: TreeItem, current_depth: int, max_depth: int) -> void:
	if not item:
		return
		
	if current_depth < max_depth:
		item.set_collapsed(false) # Mở rộng
	else:
		item.set_collapsed(true) # Thu gọn sâu bên trong
		
	var child: TreeItem = item.get_first_child()
	while child:
		_set_collapsed_depth_limit(child, current_depth + 1, max_depth)
		child = child.get_next()

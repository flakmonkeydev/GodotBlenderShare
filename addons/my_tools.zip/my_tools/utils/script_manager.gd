@tool
extends RefCounted

var plugin: EditorPlugin
var todo_btn: Button
var fix_btn: Button
var clear_btn: Button
var format_btn: Button
var doc_btn: Button
var info_btn: Button

# SỬA LỖI PHÒNG NGỪA: Sử dụng kiểu Object để phá vỡ vòng lặp biên dịch
func _init(p_plugin: Object) -> void:
	plugin = p_plugin as EditorPlugin

# Automatically inject buttons into the Script Editor toolbar
func inject_buttons() -> void:
	var editor_interface: EditorInterface = plugin.get_editor_interface()
	var script_editor: ScriptEditor = editor_interface.get_script_editor()
	var editor_base: Control = editor_interface.get_base_control()
	if not editor_base or not script_editor:
		return
		
	# Clean up any leftover duplicate buttons from previous reloads
	_remove_orphaned_buttons_recursive(script_editor, "CustomScript")
	
	var forward_icon: Texture2D = editor_base.get_theme_icon("Forward", "EditorIcons") as Texture2D
	var forward_btn: Button = _find_forward_button(script_editor, forward_icon)
	
	if forward_btn:
		var parent: Node = forward_btn.get_parent()
		var idx: int = forward_btn.get_index()
		
		todo_btn = Button.new()
		todo_btn.name = "CustomScriptTodo"
		todo_btn.text = "Todo"
		todo_btn.flat = true
		todo_btn.tooltip_text = "Add/Update TODO on the first line and Save"
		todo_btn.pressed.connect(_on_todo_pressed)
		
		fix_btn = Button.new()
		fix_btn.name = "CustomScriptFix"
		fix_btn.text = "Fix"
		fix_btn.flat = true
		fix_btn.tooltip_text = "Add/Update FIXME on the first line and Save"
		fix_btn.pressed.connect(_on_fix_pressed)
		
		clear_btn = Button.new()
		clear_btn.name = "CustomScriptClear"
		clear_btn.text = "Clear"
		clear_btn.flat = true
		clear_btn.tooltip_text = "Remove TODO/FIXME from the first line and Save"
		clear_btn.pressed.connect(_on_clear_pressed)
		
		format_btn = Button.new()
		format_btn.name = "CustomScriptFormat"
		format_btn.text = "Format"
		format_btn.flat = true
		format_btn.tooltip_text = "Clean trailing spaces, collapse empty lines, and Save"
		format_btn.pressed.connect(_on_format_pressed)
		
		doc_btn = Button.new()
		doc_btn.name = "CustomScriptDoc"
		doc_btn.text = "Doc"
		doc_btn.flat = true
		doc_btn.tooltip_text = "Auto-generate Godot 4 Docstring Template for current line and Save"
		doc_btn.pressed.connect(_on_doc_pressed)
		
		# Initialize Info button
		info_btn = Button.new()
		info_btn.name = "CustomScriptInfo"
		info_btn.text = "Info"
		info_btn.flat = true
		info_btn.tooltip_text = "Show current scene information and statistics"
		info_btn.pressed.connect(_on_info_pressed)
		
		parent.add_child(todo_btn)
		parent.move_child(todo_btn, idx + 1)
		
		parent.add_child(fix_btn)
		parent.move_child(fix_btn, idx + 2)
		
		parent.add_child(clear_btn)
		parent.move_child(clear_btn, idx + 3)
		
		parent.add_child(format_btn)
		parent.move_child(format_btn, idx + 4)
		
		parent.add_child(doc_btn)
		parent.move_child(doc_btn, idx + 5)
		
		parent.add_child(info_btn)
		parent.move_child(info_btn, idx + 6)

# Free buttons from memory when disabling the plugin
func cleanup() -> void:
	if todo_btn and is_instance_valid(todo_btn):
		todo_btn.queue_free()
	if fix_btn and is_instance_valid(fix_btn):
		fix_btn.queue_free()
	if clear_btn and is_instance_valid(clear_btn):
		clear_btn.queue_free()
	if format_btn and is_instance_valid(format_btn):
		format_btn.queue_free()
	if doc_btn and is_instance_valid(doc_btn):
		doc_btn.queue_free()
	if info_btn and is_instance_valid(info_btn):
		info_btn.queue_free()
		
	var editor_interface: EditorInterface = plugin.get_editor_interface()
	var script_editor: ScriptEditor = editor_interface.get_script_editor()
	if script_editor:
		_remove_orphaned_buttons_recursive(script_editor, "CustomScript")

func _find_forward_button(node: Node, forward_icon: Texture2D) -> Button:
	if node is Button:
		if node.icon == forward_icon:
			return node
	for child in node.get_children():
		var found: Button = _find_forward_button(child, forward_icon)
		if found:
			return found
	return null

# SỬA LỖI LỚN: Thay queue_free bằng free() để dọn dẹp bộ đệm lập tức
func _remove_orphaned_buttons_recursive(node: Node, prefix: String) -> void:
	for child in node.get_children():
		if child is Button and child.name.begins_with(prefix):
			child.free()
		else:
			_remove_orphaned_buttons_recursive(child, prefix)

func _on_todo_pressed() -> void:
	_mark_tag("TODO")

func _on_fix_pressed() -> void:
	_mark_tag("FIXME")

func _on_clear_pressed() -> void:
	_clear_tags()

func _on_format_pressed() -> void:
	_format_current_script()

func _on_doc_pressed() -> void:
	_generate_docstring()

# Triggered when Info button is pressed
func _on_info_pressed() -> void:
	var root: Node = plugin.get_editor_interface().get_edited_scene_root()
	if not root:
		var dialog: AcceptDialog = AcceptDialog.new()
		dialog.title = "Scene Info Warning"
		dialog.dialog_text = "No active scene is currently open in the editor."
		plugin.get_editor_interface().get_base_control().add_child(dialog)
		dialog.popup_centered()
		dialog.visibility_changed.connect(func(): if not dialog.visible: dialog.queue_free())
		return
		
	var scene_path: String = root.scene_file_path
	if scene_path == "":
		var dialog: AcceptDialog = AcceptDialog.new()
		dialog.title = "Scene Info Warning"
		dialog.dialog_text = "The current scene is unsaved. Please save the scene first."
		plugin.get_editor_interface().get_base_control().add_child(dialog)
		dialog.popup_centered()
		dialog.visibility_changed.connect(func(): if not dialog.visible: dialog.queue_free())
		return
		
	var file_name: String = scene_path.get_file()
	
	# File Size
	var file_size: int = 0
	var file = FileAccess.open(scene_path, FileAccess.READ)
	if file:
		file_size = file.get_length()
		file.close()
	var formatted_size: String = _format_size(file_size)
	
	# Counts by Node Class & Attached Scripts & Total Nodes
	var class_counts: Dictionary = {}
	var script_count: int = 0
	var total_nodes: int = _count_nodes_recursive(root, class_counts)
	for node in _get_all_nodes_recursive(root):
		if node.get_script() != null:
			script_count += 1
			
	# External Resources count
	var ext_resources_count: int = 0
	var tscn_file = FileAccess.open(scene_path, FileAccess.READ)
	if tscn_file:
		while tscn_file.get_position() < tscn_file.get_length():
			var line = tscn_file.get_line()
			if line.strip_edges().begins_with("[ext_resource"):
				ext_resources_count += 1
		tscn_file.close()
		
	# Build Info Text (Clean & Compact)
	var info_text: String = ""
	info_text += "=== SCENE INFORMATION ===\n"
	info_text += "Name: %s\n" % file_name
	info_text += "Path: %s\n" % scene_path
	info_text += "File Size on Disk: %s\n\n" % formatted_size
	
	info_text += "=== NODE STATISTICS ===\n"
	info_text += "Total Nodes: %d\n" % total_nodes
	info_text += "Nodes with Scripts: %d\n" % script_count
	info_text += "Unique External Dependencies: %d\n\n" % ext_resources_count
	
	info_text += "=== NODE CLASSES ===\n"
	var sorted_classes = class_counts.keys()
	sorted_classes.sort()
	for c in sorted_classes:
		info_text += "- %s: %d\n" % [c, class_counts[c]]
		
	# Spawn the Custom Dialog
	var dialog: AcceptDialog = AcceptDialog.new()
	dialog.title = "Scene Information: %s" % file_name
	
	var vbox: VBoxContainer = VBoxContainer.new()
	dialog.add_child(vbox)
	
	# Readonly TextEdit where the user can copy values
	var text_edit: TextEdit = TextEdit.new()
	text_edit.editable = false
	text_edit.wrap_mode = TextEdit.LINE_WRAPPING_BOUNDARY
	text_edit.text = info_text
	text_edit.size_flags_vertical = Control.SIZE_EXPAND_FILL
	text_edit.custom_minimum_size = Vector2(500, 350)
	vbox.add_child(text_edit)
	
	# Copy button
	var copy_btn: Button = Button.new()
	copy_btn.text = "Copy to Clipboard"
	var editor_base = plugin.get_editor_interface().get_base_control()
	if editor_base:
		copy_btn.icon = editor_base.get_theme_icon("ActionCopy", "EditorIcons")
	copy_btn.pressed.connect(func(): DisplayServer.clipboard_set(info_text))
	vbox.add_child(copy_btn)
	
	plugin.get_editor_interface().get_base_control().add_child(dialog)
	dialog.popup_centered()
	dialog.visibility_changed.connect(func(): if not dialog.visible: dialog.queue_free())

# --- HELPER FUNCTIONS ---

func _count_nodes_recursive(node: Node, counts: Dictionary) -> int:
	if not node: return 0
	var total: int = 1
	var cls_name: String = node.get_class()
	if counts.has(cls_name):
		counts[cls_name] += 1
	else:
		counts[cls_name] = 1
		
	for child in node.get_children():
		total += _count_nodes_recursive(child, counts)
	return total

func _get_all_nodes_recursive(node: Node) -> Array[Node]:
	var nodes: Array[Node] = [node]
	for child in node.get_children():
		nodes.append_array(_get_all_nodes_recursive(child))
	return nodes

func _format_size(bytes: int) -> String:
	if bytes < 1024:
		return str(bytes) + " B"
	elif bytes < 1024 * 1024:
		return "%.2f KB" % (float(bytes) / 1024.0)
	elif bytes < 1024 * 1024 * 1024:
		return "%.2f MB" % (float(bytes) / (1024.0 * 1024.0))
	else:
		return "%.2f GB" % (float(bytes) / (1024.0 * 1024.0 * 1024.0))

# --- GDSCRIPT TEXT EDITOR ACTIONS (TODO, FIX, CLEAR, FORMAT, DOC) ---

func _mark_tag(tag: String) -> void:
	var editor_interface: EditorInterface = plugin.get_editor_interface()
	var script_editor: ScriptEditor = editor_interface.get_script_editor()
	if not script_editor: return
	var current_editor = script_editor.get_current_editor()
	if not current_editor: return
	
	var code_edit: CodeEdit = current_editor.get_base_editor() as CodeEdit
	if not code_edit: return
	
	code_edit.begin_complex_operation()
	if code_edit.get_line_count() == 0:
		code_edit.insert_line_at(0, "# " + tag)
	else:
		var first_line: String = code_edit.get_line(0)
		var clean_line: String = first_line.strip_edges()
		
		if clean_line.begins_with("# TODO") or clean_line.begins_with("# FIXME"):
			code_edit.set_line(0, "# " + tag)
		else:
			code_edit.insert_line_at(0, "# " + tag)
	code_edit.end_complex_operation()
			
	var current_script: Script = script_editor.get_current_script()
	if current_script:
		current_script.source_code = code_edit.text
		ResourceSaver.save(current_script, current_script.resource_path)
		code_edit.tag_saved_version()
		
	if script_editor.has_method("save_all_scripts"):
		script_editor.call("save_all_scripts")

func _clear_tags() -> void:
	var editor_interface: EditorInterface = plugin.get_editor_interface()
	var script_editor: ScriptEditor = editor_interface.get_script_editor()
	if not script_editor: return
	var current_editor = script_editor.get_current_editor()
	if not current_editor: return
	
	var code_edit: CodeEdit = current_editor.get_base_editor() as CodeEdit
	if not code_edit: return
	
	if code_edit.get_line_count() == 0:
		return
		
	var first_line: String = code_edit.get_line(0)
	var clean_line: String = first_line.strip_edges()
	
	if clean_line.begins_with("# TODO") or clean_line.begins_with("# FIXME"):
		code_edit.begin_complex_operation()
		code_edit.remove_line_at(0)
		code_edit.end_complex_operation()
		
	var current_script: Script = script_editor.get_current_script()
	if current_script:
		current_script.source_code = code_edit.text
		ResourceSaver.save(current_script, current_script.resource_path)
		code_edit.tag_saved_version()
		
	if script_editor.has_method("save_all_scripts"):
		script_editor.call("save_all_scripts")

func _format_current_script() -> void:
	var editor_interface: EditorInterface = plugin.get_editor_interface()
	var script_editor: ScriptEditor = editor_interface.get_script_editor()
	if not script_editor: return
	var current_editor = script_editor.get_current_editor()
	if not current_editor: return
	var code_edit: CodeEdit = current_editor.get_base_editor() as CodeEdit
	if not code_edit: return
	
	var caret_line: int = code_edit.get_caret_line()
	var caret_column: int = code_edit.get_caret_column()
	var scroll_v: float = code_edit.scroll_vertical
	var scroll_h: float = code_edit.scroll_horizontal
	
	var text: String = code_edit.text
	var lines: PackedStringArray = text.split("\n")
	var cleaned_lines: PackedStringArray = []
	var was_previous_empty: bool = false
	
	for line in lines:
		var r_stripped: String = line.rstrip(" \t")
		if r_stripped == "":
			if not was_previous_empty:
				cleaned_lines.append("")
				was_previous_empty = true
		else:
			cleaned_lines.append(r_stripped)
			was_previous_empty = false
			
	while cleaned_lines.size() > 0 and cleaned_lines[-1] == "":
		cleaned_lines.remove_at(cleaned_lines.size() - 1)
	cleaned_lines.append("")
	
	var new_text: String = "\n".join(cleaned_lines)
	
	code_edit.begin_complex_operation()
	code_edit.text = new_text
	code_edit.end_complex_operation()
	
	code_edit.set_caret_line(clampi(caret_line, 0, code_edit.get_line_count() - 1))
	code_edit.set_caret_column(caret_column)
	code_edit.scroll_vertical = scroll_v
	code_edit.scroll_horizontal = scroll_h
	
	var current_script: Script = script_editor.get_current_script()
	if current_script:
		current_script.source_code = new_text
		ResourceSaver.save(current_script, current_script.resource_path)
		code_edit.tag_saved_version()
		
	if script_editor.has_method("save_all_scripts"):
		script_editor.call("save_all_scripts")
	print("[Formatter] Code formatted and cleaned successfully!")

func _generate_docstring() -> void:
	var editor_interface: EditorInterface = plugin.get_editor_interface()
	var script_editor: ScriptEditor = editor_interface.get_script_editor()
	if not script_editor: return
	var current_editor = script_editor.get_current_editor()
	if not current_editor: return
	var code_edit: CodeEdit = current_editor.get_base_editor() as CodeEdit
	if not code_edit: return
	
	var current_line: int = code_edit.get_caret_line()
	var line_text: String = code_edit.get_line(current_line)
	
	var indent: String = ""
	for c in line_text:
		if c == " " or c == "\t":
			indent += c
		else:
			break
			
	var clean_line: String = line_text.strip_edges()
	var doc_lines: Array[String] = []
	
	if clean_line.begins_with("func ") or " func " in clean_line:
		var func_pos: int = clean_line.find("func ")
		var start_paren: int = clean_line.find("(", func_pos)
		var func_name: String = "[FunctionName]"
		
		if start_paren != -1 and start_paren > func_pos + 5:
			func_name = clean_line.substr(func_pos + 5, start_paren - (func_pos + 5)).strip_edges()
			
		doc_lines.append(indent + "## [Description for function %s]" % func_name)
		
		if start_paren != -1:
			var end_paren: int = clean_line.find(")", start_paren)
			if end_paren != -1 and end_paren > start_paren:
				var params_str: String = clean_line.substr(start_paren + 1, end_paren - (start_paren + 1)).strip_edges()
				if params_str != "":
					var raw_params: PackedStringArray = params_str.split(",")
					for p in raw_params:
						var p_clean: String = p.strip_edges()
						var colon_pos: int = p_clean.find(":")
						var eq_pos: int = p_clean.find("=")
						var split_pos: int = -1
						
						if colon_pos != -1 and eq_pos != -1:
							split_pos = min(colon_pos, eq_pos)
						elif colon_pos != -1:
							split_pos = colon_pos
						elif eq_pos != -1:
							split_pos = eq_pos
							
						if split_pos != -1:
							p_clean = p_clean.substr(0, split_pos).strip_edges()
						if p_clean != "":
							doc_lines.append(indent + "## @param  %s: [Parameter description]" % p_clean)
							
				var return_pos: int = clean_line.find("->", end_paren)
				if return_pos != -1:
					var colon_end: int = clean_line.find(":", return_pos)
					var return_type: String = "void"
					if colon_end != -1:
						return_type = clean_line.substr(return_pos + 2, colon_end - (return_pos + 2)).strip_edges()
					if return_type != "void":
						doc_lines.append(indent + "## @return %s: [Return description]" % return_type)

	elif "var " in clean_line or "const " in clean_line:
		var var_pos: int = -1
		if "var " in clean_line:
			var_pos = clean_line.find("var ")
		else:
			var_pos = clean_line.find("const ")
			
		var var_name: String = "[VariableName]"
		if var_pos != -1:
			var offset: int = 4 if "var " in clean_line else 6
			var after_var: String = clean_line.substr(var_pos + 4).strip_edges()
			var colon_pos: int = after_var.find(":")
			var eq_pos: int = after_var.find("=")
			var split_pos: int = -1
			
			if colon_pos != -1 and eq_pos != -1:
				split_pos = min(colon_pos, eq_pos)
			elif colon_pos != -1:
				split_pos = colon_pos
			elif eq_pos != -1:
				split_pos = eq_pos
				
			if split_pos != -1:
				var_name = after_var.substr(0, split_pos).strip_edges()
			else:
				var_name = after_var.split(" ")[0].strip_edges()
				
		doc_lines.append(indent + "## [Description for variable %s]" % var_name)

	else:
		doc_lines.append(indent + "## [Description for this line]")

	if not doc_lines.is_empty():
		# Wrap docstring insertion under a single complex operation
		code_edit.begin_complex_operation()
		for i in range(doc_lines.size()):
			code_edit.insert_line_at(current_line + i, doc_lines[i])
		code_edit.end_complex_operation()
			
		code_edit.set_caret_line(current_line)
		code_edit.set_caret_column(indent.length() + 3)
		
		var current_script: Script = script_editor.get_current_script()
		if current_script:
			current_script.source_code = code_edit.text
			ResourceSaver.save(current_script, current_script.resource_path)
			code_edit.tag_saved_version()
			
		if script_editor.has_method("save_all_scripts"):
			script_editor.call("save_all_scripts")

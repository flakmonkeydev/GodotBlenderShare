@tool
extends EditorPlugin

# Tham chiếu tới TabContainer chính của MyAddons
var main_dock: TabContainer

# Tham chiếu tới Bookmarks Dock độc lập
var bookmarks_dock: MarginContainer

# Nạp sẵn 3 bộ quản lý phụ từ thư mục utils/ và kịch bản Bookmarks
const ScriptManager = preload("res://addons/my_tools/utils/script_manager.gd")
const FileSystemManager = preload("res://addons/my_tools/utils/filesystem_manager.gd")
const InspectorManager = preload("res://addons/my_tools/utils/inspector_manager.gd")
const BookmarksDockScript = preload("res://addons/my_tools/bookmarks/my_bookmarks_dock.gd") # Mới

# Tham chiếu thực thể của các bộ quản lý phụ
var script_mgr: RefCounted
var fs_mgr: RefCounted
var ins_mgr: RefCounted

# --- KHỞI CHẠY PLUGIN ---
func _enter_tree() -> void:
	print("[System] Activating 'Tools' plugin...")
	
	# 1. Khởi tạo TabContainer đóng vai trò làm Dock chung tên là "Tool" ở góc trên trái
	main_dock = TabContainer.new()
	main_dock.name = "Tool"
	add_control_to_dock(DOCK_SLOT_LEFT_UR, main_dock)
	
	# Quét và nạp các công cụ con trong thư mục tools/
	var tools_dir: String = "res://addons/my_tools/tools/"
	_load_sub_tools(tools_dir)
	
	# 2. Khởi tạo và gắn Bookmarks Dock độc lập vào phân vùng cột trái dưới cạnh FileSystem (Mới)
	bookmarks_dock = BookmarksDockScript.new()
	bookmarks_dock.setup_dock(self)
	add_control_to_dock(DOCK_SLOT_LEFT_BR, bookmarks_dock)
	
	# 3. Khởi tạo các Bộ quản lý phụ
	script_mgr = ScriptManager.new(self)
	fs_mgr = FileSystemManager.new(self)
	ins_mgr = InspectorManager.new(self)
	
	# 4. KÍCH HOẠT LẮNG NGHE SỰ KIỆN ĐỘNG
	var selection = get_editor_interface().get_selection()
	if selection:
		selection.selection_changed.connect(_on_selection_changed)
		
	var script_editor: ScriptEditor = get_editor_interface().get_script_editor()
	if script_editor:
		script_editor.editor_script_changed.connect(_on_script_changed)
		
	# Khởi chạy nạp nút ban đầu
	call_deferred("_inject_all_buttons")

# --- TẮT PLUGIN (DỌN DẸP BỘ NHỚ) ---
func _exit_tree() -> void:
	print("[System] Deactivating 'Tools' plugin...")
	
	# Ngắt kết nối sự kiện
	var selection = get_editor_interface().get_selection()
	if selection and selection.selection_changed.is_connected(_on_selection_changed):
		selection.selection_changed.disconnect(_on_selection_changed)
		
	var script_editor = get_editor_interface().get_script_editor()
	if script_editor and script_editor.editor_script_changed.is_connected(_on_script_changed):
		script_editor.editor_script_changed.disconnect(_on_script_changed)

	# Giải phóng Dock chung "Tool"
	if main_dock:
		remove_control_from_docks(main_dock)
		main_dock.queue_free()
		
	# Giải phóng Bookmarks Dock (Mới)
	if bookmarks_dock:
		remove_control_from_docks(bookmarks_dock)
		bookmarks_dock.queue_free()
		
	# Giải phóng các nút bấm thông qua các bộ quản lý phụ
	if script_mgr and script_mgr.has_method("cleanup"):
		script_mgr.call("cleanup")
	if fs_mgr and fs_mgr.has_method("cleanup"):
		fs_mgr.call("cleanup")
	if ins_mgr and ins_mgr.has_method("cleanup"):
		ins_mgr.call("cleanup")

# Gọi nạp toàn bộ nút bấm
func _inject_all_buttons() -> void:
	_inject_script_buttons()
	_inject_fs_buttons()
	_inject_ins_buttons()

func _inject_script_buttons() -> void:
	if script_mgr and script_mgr.has_method("inject_buttons"):
		script_mgr.call("inject_buttons")

func _inject_fs_buttons() -> void:
	if fs_mgr and fs_mgr.has_method("inject_buttons"):
		fs_mgr.call("inject_buttons")

func _inject_ins_buttons() -> void:
	if ins_mgr and ins_mgr.has_method("inject_buttons"):
		ins_mgr.call("inject_buttons")

# Sự kiện đổi Node chọn
func _on_selection_changed() -> void:
	call_deferred("_inject_ins_buttons")

# Sự kiện đổi file script
func _on_script_changed(_script: Script) -> void:
	call_deferred("_inject_script_buttons")

# =============================================================================
# HÀM QUÉT MÔ-ĐUN CON TỰ ĐỘNG
# =============================================================================

func _load_sub_tools(path: String) -> void:
	if not DirAccess.dir_exists_absolute(path):
		DirAccess.make_dir_recursive_absolute(path)
		return
		
	var dir: DirAccess = DirAccess.open(path)
	if dir:
		dir.list_dir_begin()
		var file_name: String = dir.get_next()
		
		while file_name != "":
			if not dir.current_is_dir() and file_name.ends_with(".gd"):
				var script_path: String = path + file_name
				var tool_script: GDScript = load(script_path) as GDScript
				
				if tool_script:
					var tool_instance: Node = tool_script.new()
					
					if tool_instance is Control:
						if tool_instance.has_method("setup_tool"):
							tool_instance.setup_tool(get_editor_interface())
						
						main_dock.add_child(tool_instance)
					else:
						tool_instance.queue_free()
						
			file_name = dir.get_next()

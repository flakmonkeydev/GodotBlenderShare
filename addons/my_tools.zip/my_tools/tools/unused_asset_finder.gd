@tool
extends ScrollContainer

var editor_interface: EditorInterface

# Cached results to allow instant sorting without rescanning the disk
var scanned_unused_assets: Array[Dictionary] = []

# Temporary scanning buffers
var used_paths: Dictionary = {}
var all_assets: Array[String] = []

func _init() -> void:
	# Set the display tab name for this tool
	name = "Asset Cleaner"

# Called automatically from the main manager file to pass EditorInterface
func setup_tool(ei: EditorInterface) -> void:
	editor_interface = ei
	
	size_flags_horizontal = Control.SIZE_EXPAND_FILL
	size_flags_vertical = Control.SIZE_EXPAND_FILL
	
	var vbox: VBoxContainer = VBoxContainer.new()
	vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	vbox.size_flags_vertical = Control.SIZE_EXPAND_FILL
	add_child(vbox)
	
	# Title
	var title_label: Label = Label.new()
	title_label.text = "UNUSED ASSET CLEANER"
	title_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(title_label)
	
	# Horizontal toolbar for buttons
	var toolbar: HBoxContainer = HBoxContainer.new()
	vbox.add_child(toolbar)
	
	# Button 1: Scan Unused Assets
	var scan_btn: Button = Button.new()
	scan_btn.text = "Scan Unused Assets"
	scan_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var editor_base: Control = editor_interface.get_base_control()
	if editor_base:
		scan_btn.icon = editor_base.get_theme_icon("Search", "EditorIcons")
	scan_btn.pressed.connect(_on_scan_btn_pressed)
	toolbar.add_child(scan_btn)
	
	# Button 2: Sort Option (Dropdown menu)
	var sort_option: OptionButton = OptionButton.new()
	sort_option.name = "SortOption"
	sort_option.add_item("Sort by Name")
	sort_option.add_item("Sort by Size (Ascending)")
	sort_option.add_item("Sort by Size (Descending)")
	sort_option.selected = 0 # Default to Name
	sort_option.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sort_option.item_selected.connect(_on_sort_selected)
	toolbar.add_child(sort_option)
	
	# Button 3: Help
	var help_btn: Button = Button.new()
	help_btn.text = "Help"
	help_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	if editor_base:
		help_btn.icon = editor_base.get_theme_icon("Help", "EditorIcons")
	help_btn.pressed.connect(_on_help_btn_pressed)
	toolbar.add_child(help_btn)
	
	# Tree table to display results
	var tree_control: Tree = Tree.new()
	tree_control.name = "UnusedAssetTree"
	tree_control.columns = 2
	tree_control.column_titles_visible = true
	tree_control.set_column_title(0, "Unused Asset Path")
	tree_control.set_column_title(1, "Size")
	tree_control.set_column_expand(1, false)
	tree_control.set_column_custom_minimum_width(1, 150)
	tree_control.set_column_expand(0, true)
	tree_control.size_flags_vertical = Control.SIZE_EXPAND_FILL
	
	# Double click item to navigate FileSystem
	tree_control.item_activated.connect(_on_item_activated)
	vbox.add_child(tree_control)
	
	# --- SUMMARY PANEL ---
	var summary_panel: PanelContainer = PanelContainer.new()
	vbox.add_child(summary_panel)
	
	var summary_vbox: VBoxContainer = VBoxContainer.new()
	summary_panel.add_child(summary_vbox)
	
	var summary_label: Label = Label.new()
	summary_label.name = "SummaryLabel"
	summary_label.text = "Total unused files: 0 | Wasted size: 0 B"
	summary_vbox.add_child(summary_label)

# Triggered when 'Scan Unused Assets' is pressed
func _on_scan_btn_pressed() -> void:
	# Clean up cached lists
	scanned_unused_assets.clear()
	used_paths.clear()
	all_assets.clear()
	
	# Scan the project directory
	_scan_project_recursive("res://")
	
	# Check each collected asset path against used paths
	for asset_path in all_assets:
		if not used_paths.has(asset_path):
			var file_size: int = _get_file_size(asset_path)
			scanned_unused_assets.append({
				"path": asset_path,
				"size": file_size
			})
			
	# Populate Tree list
	_update_tree_ui()

# Triggered when sorting dropdown changes option
func _on_sort_selected(_index: int) -> void:
	_update_tree_ui()

# Pop up a clean native AcceptDialog containing the instructions when 'Help' is clicked
func _on_help_btn_pressed() -> void:
	var dialog: AcceptDialog = AcceptDialog.new()
	dialog.title = "Unused Assets Instructions"
	dialog.dialog_text = "How to use this tool:\n\n" + \
		"1. Press 'Scan Unused Assets' to scan the project directory for files (images, audio, models) that are NOT referenced by any scene, script, or resource.\n\n" + \
		"2. Select a sorting mode from the dropdown menu to organize the list by Name, Size Ascending, or Size Descending instantly.\n\n" + \
		"3. Double-click any item in the list to automatically navigate and highlight that file inside the FileSystem dock below.\n\n" + \
		"* Warning:\n" + \
		"Please double-check files before deleting them manually. Some assets might be loaded dynamically in code (e.g. 'res://level_' + str(i)), which cannot be detected by static text analysis."
		
	editor_interface.get_base_control().add_child(dialog)
	dialog.popup_centered(Vector2(450, 320))
	dialog.visibility_changed.connect(func(): if not dialog.visible: dialog.queue_free())

# Sort cached items and redraw the Tree list instantly
func _update_tree_ui() -> void:
	var tree_ctrl: Tree = find_child("UnusedAssetTree", true, false) as Tree
	var summary: Label = find_child("SummaryLabel", true, false) as Label
	var sort_option: OptionButton = find_child("SortOption", true, false) as OptionButton
	
	if not tree_ctrl or not summary or not sort_option:
		printerr("[System] Please disable and re-enable the plugin in Project Settings to refresh the UI.")
		return
		
	tree_ctrl.clear()
	var root_item: TreeItem = tree_ctrl.create_item()
	root_item.set_text(0, "res://")
	
	var sorted_assets: Array[Dictionary] = scanned_unused_assets.duplicate()
	var sort_mode: int = sort_option.selected
	
	# Sort based on selected option
	match sort_mode:
		0: # Sort by Name
			sorted_assets.sort_custom(func(a: Dictionary, b: Dictionary) -> bool:
				return a["path"].get_file().naturalnocasecmp_to(b["path"].get_file()) < 0
			)
		1: # Sort by Size (Ascending)
			sorted_assets.sort_custom(func(a: Dictionary, b: Dictionary) -> bool:
				return a["size"] < b["size"]
			)
		2: # Sort by Size (Descending)
			sorted_assets.sort_custom(func(a: Dictionary, b: Dictionary) -> bool:
				return a["size"] > b["size"]
			)
			
	# Populate sorted items
	var total_wasted_size: int = 0
	for item in sorted_assets:
		total_wasted_size += item["size"]
		var child_item: TreeItem = tree_ctrl.create_item(root_item)
		child_item.set_text(0, item["path"])
		child_item.set_text(1, _format_size(item["size"]))
		child_item.set_metadata(0, item["path"])
		
	root_item.set_collapsed(false)
	summary.text = "Total unused files: %d | Wasted size: %s" % [sorted_assets.size(), _format_size(total_wasted_size)]

# Double-click handler: select and highlight the file in the FileSystem dock
func _on_item_activated() -> void:
	var tree_ctrl: Tree = find_child("UnusedAssetTree", true, false) as Tree
	if not tree_ctrl:
		return
		
	var selected_item: TreeItem = tree_ctrl.get_selected()
	if selected_item:
		var file_path = selected_item.get_metadata(0)
		if file_path is String and file_path != "":
			editor_interface.select_file(file_path)
			print("[Cleaner] Navigated FileSystem to: ", file_path)

# Recursively scan project directory (harvest references and collect asset files)
func _scan_project_recursive(path: String) -> void:
	var path_lower: String = path.to_lower()
	if path == "res://.godot" or path.begins_with("res://.godot/") or path == "res://addons" or path.begins_with("res://addons/"):
		return
		
	var dir: DirAccess = DirAccess.open(path)
	if dir:
		var files: PackedStringArray = dir.get_files()
		for file_name: String in files:
			var file_path: String = path.path_join(file_name)
			var ext: String = file_name.get_extension().to_lower()
			
			if ext in ["tscn", "tres", "gd", "cs", "json", "godot"]:
				_harvest_paths_from_file(file_path)
			elif ext in ["png", "jpg", "jpeg", "svg", "tga", "bmp", "dds", "wav", "mp3", "ogg", "flac", "glb", "gltf", "fbx", "obj", "dae", "blend", "ttf", "otf", "woff", "woff2", "material"]:
				all_assets.append(file_path)
				
		var subdirs: PackedStringArray = dir.get_directories()
		for subdir_name: String in subdirs:
			var subdir_path: String = path.path_join(subdir_name)
			_scan_project_recursive(subdir_path)

# Parse text file contents to extract any "res://" path references
func _harvest_paths_from_file(file_path: String) -> void:
	var file: FileAccess = FileAccess.open(file_path, FileAccess.READ)
	if file:
		while file.get_position() < file.get_length():
			var line: String = file.get_line()
			var pos: int = line.find("res://")
			
			while pos != -1:
				var end_chars: Array[String] = ["\"", "'", " ", "]", ")", ">", ",", ";", "\n", "\r", "\t"]
				var end_pos: int = line.length()
				for c in end_chars:
					var c_pos = line.find(c, pos)
					if c_pos != -1 and c_pos < end_pos:
						end_pos = c_pos
						
				var found_path: String = line.substr(pos, end_pos - pos).strip_edges()
				used_paths[found_path] = true
				
				pos = line.find("res://", end_pos)
		file.close()

# Get file size in bytes
func _get_file_size(path: String) -> int:
	var file: FileAccess = FileAccess.open(path, FileAccess.READ)
	if file:
		var size: int = file.get_length()
		file.close()
		return size
	return 0

# Format raw bytes into human-readable size string
func _format_size(bytes: int) -> String:
	if bytes < 1024:
		return str(bytes) + " B"
	elif bytes < 1024 * 1024:
		return "%.2f KB" % (float(bytes) / 1024.0)
	elif bytes < 1024 * 1024 * 1024:
		return "%.2f MB" % (float(bytes) / (1024.0 * 1024.0))
	else:
		return "%.2f GB" % (float(bytes) / (1024.0 * 1024.0 * 1024.0))

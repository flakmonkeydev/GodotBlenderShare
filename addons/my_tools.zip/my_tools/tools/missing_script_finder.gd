@tool
extends ScrollContainer

var editor_interface: EditorInterface

# Scan counters for reporting
var scenes_scanned: int = 0
var missing_count: int = 0

func _init() -> void:
	name = "Missing Scripts"

# Called automatically from the main manager file to pass EditorInterface
func setup_tool(ei: EditorInterface) -> void:
	editor_interface = ei
	
	size_flags_horizontal = Control.SIZE_EXPAND_FILL
	size_flags_vertical = Control.SIZE_EXPAND_FILL
	
	var vbox: VBoxContainer = VBoxContainer.new()
	vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	vbox.size_flags_vertical = Control.SIZE_EXPAND_FILL
	add_child(vbox)
	
	# Title
	var title_label: Label = Label.new()
	title_label.text = "MISSING SCRIPT FINDER"
	title_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(title_label)
	
	# Horizontal toolbar for buttons
	var toolbar: HBoxContainer = HBoxContainer.new()
	vbox.add_child(toolbar)
	
	# Button 1: Scan Project
	var scan_btn: Button = Button.new()
	scan_btn.text = "Scan Project"
	scan_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var editor_base: Control = editor_interface.get_base_control()
	if editor_base:
		scan_btn.icon = editor_base.get_theme_icon("Search", "EditorIcons")
	scan_btn.pressed.connect(_on_scan_btn_pressed)
	toolbar.add_child(scan_btn)
	
	# Button 2: Help (Replaces the bulky instructions label)
	var help_btn: Button = Button.new()
	help_btn.text = "Help"
	help_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	if editor_base:
		help_btn.icon = editor_base.get_theme_icon("Help", "EditorIcons")
	help_btn.pressed.connect(_on_help_btn_pressed)
	toolbar.add_child(help_btn)
	
	# Tree table to display results
	var tree_control: Tree = Tree.new()
	tree_control.name = "MissingScriptTree"
	tree_control.columns = 3
	tree_control.column_titles_visible = true
	tree_control.set_column_title(0, "Broken Scene")
	tree_control.set_column_title(1, "Missing Script Path")
	tree_control.set_column_title(2, "Scene Path")
	
	# Auto-stretch with natural balance
	tree_control.set_column_expand(0, true)
	tree_control.set_column_expand(1, true)
	tree_control.set_column_expand(2, true)
	tree_control.set_column_expand_ratio(0, 1)
	tree_control.set_column_expand_ratio(1, 2)
	tree_control.set_column_expand_ratio(2, 2)
	
	tree_control.set_column_clip_content(0, true)
	tree_control.set_column_clip_content(1, true)
	tree_control.set_column_clip_content(2, true)
	
	tree_control.set_column_custom_minimum_width(0, 100)
	tree_control.set_column_custom_minimum_width(1, 150)
	tree_control.set_column_custom_minimum_width(2, 150)
	
	tree_control.size_flags_vertical = Control.SIZE_EXPAND_FILL
	
	# Double click item to jump to code
	tree_control.item_activated.connect(_on_item_activated)
	vbox.add_child(tree_control)

# Triggered when 'Scan Project' is pressed
func _on_scan_btn_pressed() -> void:
	var tree_ctrl: Tree = find_child("MissingScriptTree", true, false) as Tree
	if not tree_ctrl:
		return
		
	tree_ctrl.clear()
	var root_item: TreeItem = tree_ctrl.create_item()
	root_item.set_text(0, "Project")
	
	# Reset scan counters
	scenes_scanned = 0
	missing_count = 0
	
	# Recursively scan the project directory
	_scan_scenes_recursive("res://", root_item)
	root_item.set_collapsed(false)
	
	# Report results to the Godot output console
	if missing_count > 0:
		print_rich("[color=red][System] Scan completed! Checked %d scenes. Found %d missing script errors.[/color]" % [scenes_scanned, missing_count])
	else:
		print_rich("[color=green][System] Scan completed! Checked %d scenes. No missing script errors found (Project clean).[/color]" % [scenes_scanned])

# Pop up a clean native AcceptDialog containing the instructions when 'Help' is clicked
func _on_help_btn_pressed() -> void:
	var dialog: AcceptDialog = AcceptDialog.new()
	dialog.title = "Missing Scripts Instructions"
	dialog.dialog_text = "How to use this tool:\n\n" + \
		"1. Press 'Scan Project' to scan all scene (.tscn) files in the project.\n\n" + \
		"2. The tool will parse each scene's dependencies and check if any attached script files are missing or deleted from your computer's hard drive.\n\n" + \
		"3. If any missing scripts are detected, they will be listed in the table.\n\n" + \
		"4. Double-click any row to automatically open that specific broken scene in the editor so you can re-attach or fix the script."
		
	editor_interface.get_base_control().add_child(dialog)
	dialog.popup_centered(Vector2(450, 300))
	dialog.visibility_changed.connect(func(): if not dialog.visible: dialog.queue_free())

# Recursive scene file scanning
func _scan_scenes_recursive(path: String, root_item: TreeItem) -> void:
	# Exclude system folders and the plugin's folder
	if path == "res://.godot" or path.begins_with("res://.godot/") or path == "res://addons" or path.begins_with("res://addons/"):
		return
		
	var dir: DirAccess = DirAccess.open(path)
	if dir:
		var files: PackedStringArray = dir.get_files()
		for file_name: String in files:
			if file_name.ends_with(".tscn"):
				var file_path: String = path.path_join(file_name)
				_check_scene_for_missing_scripts(file_path, root_item)
				
		var subdirs: PackedStringArray = dir.get_directories()
		for subdir_name: String in subdirs:
			var subdir_path: String = path.path_join(subdir_name)
			_scan_scenes_recursive(subdir_path, root_item)

# Parse .tscn file as plain text to find missing script references
func _check_scene_for_missing_scripts(file_path: String, root_item: TreeItem) -> void:
	var file: FileAccess = FileAccess.open(file_path, FileAccess.READ)
	if file:
		scenes_scanned += 1
		var missing_scripts: Array[String] = []
		
		while file.get_position() < file.get_length():
			var line: String = file.get_line()
			var clean_line: String = line.strip_edges()
			
			# Early break optimization: ext_resource is always at the top.
			# When we hit the first [node], we can stop reading to save CPU.
			if clean_line.begins_with("[node"):
				break
			
			# Check if the line is an external script dependency
			if clean_line.begins_with("[ext_resource") and "type=\"Script\"" in clean_line:
				var path_start: int = clean_line.find("path=\"")
				if path_start != -1:
					var path_end: int = clean_line.find("\"", path_start + 6)
					if path_end != -1:
						var script_path: String = clean_line.substr(path_start + 6, path_end - (path_start + 6))
						
						# Verify if the script file actually exists on the hard drive
						if not FileAccess.file_exists(script_path):
							missing_scripts.append(script_path)
							
		file.close()
		
		# If missing scripts are found, append them to the Tree list
		if not missing_scripts.is_empty():
			var tree_ctrl: Tree = find_child("MissingScriptTree", true, false) as Tree
			if tree_ctrl:
				for script_path: String in missing_scripts:
					missing_count += 1
					var item: TreeItem = tree_ctrl.create_item(root_item)
					item.set_text(0, file_path.get_file())
					item.set_text(1, script_path)
					item.set_text(2, file_path)
					item.set_metadata(0, file_path)

# Double-click handler: open the broken scene file
func _on_item_activated() -> void:
	var tree_ctrl: Tree = find_child("MissingScriptTree", true, false) as Tree
	if not tree_ctrl:
		return
		
	var selected_item: TreeItem = tree_ctrl.get_selected()
	if selected_item:
		var scene_path = selected_item.get_metadata(0)
		if scene_path is String and scene_path != "":
			editor_interface.open_scene_from_path(scene_path)
			print("-> Opened broken scene: ", scene_path)

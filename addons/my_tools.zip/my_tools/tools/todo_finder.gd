@tool
extends ScrollContainer

var editor_interface: EditorInterface

func _init() -> void:
	name = "TODO Finder"

func setup_tool(ei: EditorInterface) -> void:
	editor_interface = ei
	size_flags_horizontal = Control.SIZE_EXPAND_FILL
	size_flags_vertical = Control.SIZE_EXPAND_FILL
	
	var vbox: VBoxContainer = VBoxContainer.new()
	vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	vbox.size_flags_vertical = Control.SIZE_EXPAND_FILL
	add_child(vbox)
	
	var title_label: Label = Label.new()
	title_label.text = "TODO & FIXME FINDER"
	title_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(title_label)
	
	# Horizontal toolbar for buttons
	var hbox: HBoxContainer = HBoxContainer.new()
	vbox.add_child(hbox)
	
	# Button 1: Scan
	var scan_btn: Button = Button.new()
	scan_btn.text = "Scan Script (.gd)"
	scan_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var editor_base: Control = editor_interface.get_base_control()
	if editor_base:
		scan_btn.icon = editor_base.get_theme_icon("Script", "EditorIcons")
	scan_btn.pressed.connect(_on_scan_btn_pressed)
	hbox.add_child(scan_btn)
	
	# Button 2: Clear List
	var clear_list_btn: Button = Button.new()
	clear_list_btn.text = "Clear List"
	clear_list_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	if editor_base:
		clear_list_btn.icon = editor_base.get_theme_icon("Clear", "EditorIcons")
	clear_list_btn.pressed.connect(_on_clear_list_btn_pressed)
	hbox.add_child(clear_list_btn)
	
	# Button 3: Help
	var help_btn: Button = Button.new()
	help_btn.text = "Help"
	help_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	if editor_base:
		help_btn.icon = editor_base.get_theme_icon("Help", "EditorIcons")
	help_btn.pressed.connect(_on_help_btn_pressed)
	hbox.add_child(help_btn)
	
	# Tree table to display results
	var tree_control: Tree = Tree.new()
	tree_control.name = "TodoTree"
	tree_control.columns = 2
	tree_control.column_titles_visible = true
	tree_control.set_column_title(0, "Script File Name")
	tree_control.set_column_title(1, "Tag")
	
	# --- SMART COLUMN SIZING CONFIGURATION ---
	# Column 1 (Tag) is kept compact and fixed (150px)
	tree_control.set_column_expand(1, false)
	tree_control.set_column_custom_minimum_width(1, 150)
	
	# Column 0 (Script File Name) expands to fill the remaining space
	tree_control.set_column_expand(0, true)
	
	# Clip content to prevent layout breakage
	tree_control.set_column_clip_content(0, true)
	tree_control.set_column_clip_content(1, true)
	
	tree_control.size_flags_vertical = Control.SIZE_EXPAND_FILL
	
	# Double click item to jump to code
	tree_control.item_activated.connect(_on_item_activated)
	vbox.add_child(tree_control)

# Triggered when 'Scan Script' is pressed
func _on_scan_btn_pressed() -> void:
	var tree_ctrl: Tree = find_child("TodoTree", true, false) as Tree
	if not tree_ctrl:
		return
		
	tree_ctrl.clear()
	var root_item: TreeItem = tree_ctrl.create_item()
	root_item.set_text(0, "Project")
	
	_scan_todos_recursive("res://", root_item)
	root_item.set_collapsed(false)

# Triggered when 'Clear List' is pressed
func _on_clear_list_btn_pressed() -> void:
	var tree_ctrl: Tree = find_child("TodoTree", true, false) as Tree
	if tree_ctrl:
		tree_ctrl.clear()

# Pop up a clean native AcceptDialog containing the instructions when 'Help' is clicked
func _on_help_btn_pressed() -> void:
	var dialog: AcceptDialog = AcceptDialog.new()
	dialog.title = "TODO Finder Instructions"
	dialog.dialog_text = "How to use this tool:\n\n" + \
		"1. Press 'Scan Script (.gd)' to scan all GDScript (.gd) files in your project.\n\n" + \
		"2. The tool will search for lines containing '# TODO' or '# FIXME' comments and list them in the table.\n\n" + \
		"3. Double-click any item in the list to open the script file and jump directly to that specific line.\n\n" + \
		"4. Press 'Clear List' to empty the results table."
		
	editor_interface.get_base_control().add_child(dialog)
	dialog.popup_centered(Vector2(450, 300))
	
	# Safely free the dialog from memory when closed
	dialog.visibility_changed.connect(func(): if not dialog.visible: dialog.queue_free())

# Recursive directory scanning
func _scan_todos_recursive(path: String, root_item: TreeItem) -> void:
	# Exclude system folders and any folder containing "addon" (case-insensitive)
	var path_lower: String = path.to_lower()
	if "addon" in path_lower or ".godot" in path_lower:
		return
		
	var dir: DirAccess = DirAccess.open(path)
	if dir:
		var files: PackedStringArray = dir.get_files()
		for file_name: String in files:
			if file_name.ends_with(".gd"):
				var file_path: String = path.path_join(file_name)
				_check_file_for_todos(file_path, root_item)
				
		var subdirs: PackedStringArray = dir.get_directories()
		for subdir_name: String in subdirs:
			var subdir_path: String = path.path_join(subdir_name)
			_scan_todos_recursive(subdir_path, root_item)

# Parse .gd file for lines containing # TODO or # FIXME
func _check_file_for_todos(file_path: String, root_item: TreeItem) -> void:
	var file: FileAccess = FileAccess.open(file_path, FileAccess.READ)
	if file:
		var line_num: int = 1
		var tree_ctrl: Tree = find_child("TodoTree", true, false) as Tree
		if not tree_ctrl:
			file.close()
			return
			
		while file.get_position() < file.get_length():
			var line: String = file.get_line()
			var clean_line: String = line.strip_edges()
			
			if clean_line.contains("# TODO") or clean_line.contains("# FIXME"):
				var item: TreeItem = tree_ctrl.create_item(root_item)
				item.set_text(0, file_path.get_file())
				item.set_text(1, clean_line)
				
				# Save file path and line number in metadata
				item.set_metadata(0, file_path)
				item.set_metadata(1, line_num)
				
			line_num += 1
		file.close()

# Double-click handler: open the script and navigate to the line
func _on_item_activated() -> void:
	var tree_ctrl: Tree = find_child("TodoTree", true, false) as Tree
	if not tree_ctrl:
		return
		
	var selected_item: TreeItem = tree_ctrl.get_selected()
	if selected_item:
		var file_path = selected_item.get_metadata(0)
		var line_num = selected_item.get_metadata(1)
		
		if file_path is String and file_path != "":
			var script_res: Script = load(file_path) as Script
			if script_res:
				var line: int = line_num if line_num is int else 1
				editor_interface.edit_script(script_res, line)

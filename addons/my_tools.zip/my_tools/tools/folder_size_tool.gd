@tool
extends ScrollContainer

var editor_interface: EditorInterface

# Cached results to allow instant sorting without rescanning the disk
var scanned_items: Array[Dictionary] = []
var root_files_size: int = 0

func _init() -> void:
	# Set the display tab name for this tool
	name = "Folder Sizes"

# Called automatically from the main manager file to pass EditorInterface
func setup_tool(ei: EditorInterface) -> void:
	editor_interface = ei
	
	size_flags_horizontal = Control.SIZE_EXPAND_FILL
	size_flags_vertical = Control.SIZE_EXPAND_FILL
	
	var vbox: VBoxContainer = VBoxContainer.new()
	vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	vbox.size_flags_vertical = Control.SIZE_EXPAND_FILL
	add_child(vbox)
	
	# Title
	var title_label: Label = Label.new()
	title_label.text = "PROJECT FOLDER SIZES"
	title_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(title_label)
	
	# Horizontal toolbar for buttons
	var toolbar: HBoxContainer = HBoxContainer.new()
	vbox.add_child(toolbar)
	
	# Button 1: Calculate Sizes
	var calc_btn: Button = Button.new()
	calc_btn.text = "Calculate Sizes"
	calc_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var editor_base: Control = editor_interface.get_base_control()
	if editor_base:
		calc_btn.icon = editor_base.get_theme_icon("SearchPath", "EditorIcons")
	calc_btn.pressed.connect(_on_calc_btn_pressed)
	toolbar.add_child(calc_btn)
	
	# Button 2: Sort Option (Dropdown menu)
	var sort_option: OptionButton = OptionButton.new()
	sort_option.name = "SortOption"
	sort_option.add_item("Sort by Name")
	sort_option.add_item("Sort by Size (Ascending)")
	sort_option.add_item("Sort by Size (Descending)")
	sort_option.selected = 0 # Default to Name
	sort_option.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sort_option.item_selected.connect(_on_sort_selected)
	toolbar.add_child(sort_option)
	
	# Button 3: Help
	var help_btn: Button = Button.new()
	help_btn.text = "Help"
	help_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	if editor_base:
		help_btn.icon = editor_base.get_theme_icon("Help", "EditorIcons")
	help_btn.pressed.connect(_on_help_btn_pressed)
	toolbar.add_child(help_btn)
	
	# Tree table to display results
	var tree_control: Tree = Tree.new()
	tree_control.name = "FolderSizeTree"
	tree_control.columns = 2
	tree_control.column_titles_visible = true
	tree_control.set_column_title(0, "Subfolder (res://)")
	tree_control.set_column_title(1, "Actual Size")
	tree_control.size_flags_vertical = Control.SIZE_EXPAND_FILL
	vbox.add_child(tree_control)
	
	# --- SUMMARY & ESTIMATION PANEL ---
	var summary_panel: PanelContainer = PanelContainer.new()
	vbox.add_child(summary_panel)
	
	var summary_vbox: VBoxContainer = VBoxContainer.new()
	summary_panel.add_child(summary_vbox)
	
	var total_project_label: Label = Label.new()
	total_project_label.name = "TotalProjectLabel"
	total_project_label.text = "Total project size (res://): Not calculated"
	summary_vbox.add_child(total_project_label)
	
	var est_export_label: Label = Label.new()
	est_export_label.name = "EstExportLabel"
	est_export_label.text = "Estimated export size (.pck): Not calculated"
	summary_vbox.add_child(est_export_label)

# Triggered when 'Calculate Sizes' button is pressed
func _on_calc_btn_pressed() -> void:
	# Clean up old caches before scanning
	scanned_items.clear()
	root_files_size = 0
	
	var dir: DirAccess = DirAccess.open("res://")
	if dir:
		var subdirs: PackedStringArray = dir.get_directories()
		for subdir_name: String in subdirs:
			var folder_path: String = "res://".path_join(subdir_name)
			var size: int = _get_folder_size(folder_path)
			
			# Cache results for instant sorting
			scanned_items.append({
				"name": subdir_name + "/",
				"size": size
			})
		
		# Measure loose files at root res://
		var root_files: PackedStringArray = dir.get_files()
		for file_name: String in root_files:
			var file_path: String = "res://".path_join(file_name)
			var file: FileAccess = FileAccess.open(file_path, FileAccess.READ)
			if file:
				root_files_size += file.get_length()
				file.close()
				
	# Populate Tree UI
	_update_tree_ui()

# Triggered when sorting dropdown changes option
func _on_sort_selected(_index: int) -> void:
	_update_tree_ui()

# Pop up a clean native AcceptDialog containing the instructions when 'Help' is clicked
func _on_help_btn_pressed() -> void:
	var dialog: AcceptDialog = AcceptDialog.new()
	dialog.title = "Folder Sizes Instructions"
	dialog.dialog_text = "How to use this tool:\n\n" + \
		"1. Press 'Calculate Sizes' to scan the project directory and measure the size of all subdirectories.\n\n" + \
		"2. Select a sorting mode from the dropdown menu to organize the list by Name, Size Ascending, or Size Descending instantly.\n\n" + \
		"* Notes on Estimated Export Size:\n" + \
		"The estimated export size (.pck) is calculated by combining the compressed assets folder (.godot/imported) and unimported script/scene files, \n
		 while completely excluding raw uncompressed source files (like original .png, .wav, .fbx files) which Godot does not package into the final game."
	
	# Add to editor base control to apply the native dark theme properly
	editor_interface.get_base_control().add_child(dialog)
	dialog.popup_centered(Vector2(450, 320))
	
	# Safely free the dialog from memory when closed
	dialog.visibility_changed.connect(func(): if not dialog.visible: dialog.queue_free())

# Sort cached items and redraw the Tree list instantly
func _update_tree_ui() -> void:
	var tree_ctrl: Tree = find_child("FolderSizeTree", true, false) as Tree
	var total_label: Label = find_child("TotalProjectLabel", true, false) as Label
	var est_label: Label = find_child("EstExportLabel", true, false) as Label
	var sort_option: OptionButton = find_child("SortOption", true, false) as OptionButton
	
	if not tree_ctrl or not total_label or not est_label or not sort_option:
		printerr("[System] Please disable and re-enable the plugin in Project Settings to refresh the UI.")
		return
		
	tree_ctrl.clear()
	var root_item: TreeItem = tree_ctrl.create_item()
	root_item.set_text(0, "res://")
	
	var sorted_items: Array[Dictionary] = scanned_items.duplicate()
	var sort_mode: int = sort_option.selected
	
	# Sort based on selected option
	match sort_mode:
		0: # Sort by Name
			sorted_items.sort_custom(func(a: Dictionary, b: Dictionary) -> bool:
				return a["name"].naturalnocasecmp_to(b["name"]) < 0
			)
		1: # Sort by Size (Ascending)
			sorted_items.sort_custom(func(a: Dictionary, b: Dictionary) -> bool:
				return a["size"] < b["size"]
			)
		2: # Sort by Size (Descending)
			sorted_items.sort_custom(func(a: Dictionary, b: Dictionary) -> bool:
				return a["size"] > b["size"]
			)
			
	# Populate sorted items
	var total_project_size: int = 0
	for item in sorted_items:
		total_project_size += item["size"]
		var child_item: TreeItem = tree_ctrl.create_item(root_item)
		child_item.set_text(0, item["name"])
		child_item.set_text(1, _format_size(item["size"]))
		
	# Append root files at the bottom
	total_project_size += root_files_size
	if root_files_size > 0:
		var files_item: TreeItem = tree_ctrl.create_item(root_item)
		files_item.set_text(0, "[Files at Root]")
		files_item.set_text(1, _format_size(root_files_size))
		
	root_item.set_collapsed(false)
	
	# Update labels
	total_label.text = "Total project size (res://): " + _format_size(total_project_size)
	var est_export_size: int = _calculate_estimated_export_size()
	est_label.text = "Estimated export size (.pck): " + _format_size(est_export_size)

# Recursively calculate the size of a directory
func _get_folder_size(path: String) -> int:
	var total_size: int = 0
	var dir: DirAccess = DirAccess.open(path)
	if dir:
		var files: PackedStringArray = dir.get_files()
		for file_name: String in files:
			var file_path: String = path.path_join(file_name)
			var file: FileAccess = FileAccess.open(file_path, FileAccess.READ)
			if file:
				total_size += file.get_length()
				file.close()
		
		var subdirs: PackedStringArray = dir.get_directories()
		for subdir_name: String in subdirs:
			var subdir_path: String = path.path_join(subdir_name)
			total_size += _get_folder_size(subdir_path)
	return total_size

# Calculate estimated exported PCK size
func _calculate_estimated_export_size() -> int:
	var imported_size: int = _get_folder_size("res://.godot/imported")
	var other_size: int = _get_export_files_size_recursive("res://")
	return imported_size + other_size

# Recursively filter and calculate files to be exported
func _get_export_files_size_recursive(path: String) -> int:
	var size: int = 0
	if path.begins_with("res://.godot"):
		return 0
		
	var dir: DirAccess = DirAccess.open(path)
	if dir:
		var files: PackedStringArray = dir.get_files()
		var import_files_tracker: Dictionary = {}
		for file_name: String in files:
			if file_name.ends_with(".import"):
				var raw_name: String = file_name.trim_suffix(".import")
				import_files_tracker[raw_name] = true
		
		for file_name: String in files:
			if file_name.ends_with(".import"):
				continue
			if import_files_tracker.has(file_name):
				continue
				
			var file_path: String = path.path_join(file_name)
			var file: FileAccess = FileAccess.open(file_path, FileAccess.READ)
			if file:
				size += file.get_length()
				file.close()
				
		var subdirs: PackedStringArray = dir.get_directories()
		for subdir_name: String in subdirs:
			var subdir_path: String = path.path_join(subdir_name)
			size += _get_export_files_size_recursive(subdir_path)
			
	return size

# Format raw bytes into human-readable size string
func _format_size(bytes: int) -> String:
	if bytes < 1024:
		return str(bytes) + " B"
	elif bytes < 1024 * 1024:
		return "%.2f KB" % (float(bytes) / 1024.0)
	elif bytes < 1024 * 1024 * 1024:
		return "%.2f MB" % (float(bytes) / (1024.0 * 1024.0))
	else:
		return "%.2f GB" % (float(bytes) / (1024.0 * 1024.0 * 1024.0))

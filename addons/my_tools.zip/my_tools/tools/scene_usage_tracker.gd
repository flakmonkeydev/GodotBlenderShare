@tool
extends ScrollContainer

var editor_interface: EditorInterface

func _init() -> void:
	# Set the display tab name inside the Tool dock container
	name = "Scene Usage"

# Called automatically from the main manager file to pass EditorInterface
func setup_tool(ei: EditorInterface) -> void:
	editor_interface = ei
	
	size_flags_horizontal = Control.SIZE_EXPAND_FILL
	size_flags_vertical = Control.SIZE_EXPAND_FILL
	
	var vbox: VBoxContainer = VBoxContainer.new()
	vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	vbox.size_flags_vertical = Control.SIZE_EXPAND_FILL
	add_child(vbox)
	
	# Title
	var title_label: Label = Label.new()
	title_label.text = "CURRENT SCENE USAGE & DEPENDENCIES"
	title_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(title_label)
	
	# Toolbar
	var toolbar: HBoxContainer = HBoxContainer.new()
	vbox.add_child(toolbar)
	
	# Button 1: Scan
	var scan_btn: Button = Button.new()
	scan_btn.text = "Scan Active Scene"
	scan_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var editor_base: Control = editor_interface.get_base_control()
	if editor_base:
		scan_btn.icon = editor_base.get_theme_icon("Search", "EditorIcons")
	scan_btn.pressed.connect(_on_scan_btn_pressed)
	toolbar.add_child(scan_btn)
	
	# Button 2: Clear List (Mới)
	var clear_btn: Button = Button.new()
	clear_btn.text = "Clear List"
	clear_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	if editor_base:
		clear_btn.icon = editor_base.get_theme_icon("Clear", "EditorIcons")
	clear_btn.pressed.connect(_on_clear_btn_pressed)
	toolbar.add_child(clear_btn)
	
	# Button 3: Help
	var help_btn: Button = Button.new()
	help_btn.text = "Help"
	help_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	if editor_base:
		help_btn.icon = editor_base.get_theme_icon("Help", "EditorIcons")
	help_btn.pressed.connect(_on_help_btn_pressed)
	toolbar.add_child(help_btn)
	
	# Tree Table to display results
	var tree_control: Tree = Tree.new()
	tree_control.name = "UsageTree"
	tree_control.columns = 2
	tree_control.column_titles_visible = true
	tree_control.set_column_title(0, "Scene Path")
	tree_control.set_column_title(1, "Relation Type")
	
	tree_control.set_column_expand(0, true)
	tree_control.set_column_expand(1, false)
	tree_control.set_column_custom_minimum_width(1, 150)
	
	tree_control.set_column_clip_content(0, true)
	tree_control.set_column_clip_content(1, true)
	
	tree_control.size_flags_vertical = Control.SIZE_EXPAND_FILL
	
	# Double click row to open that scene file instantly
	tree_control.item_activated.connect(_on_item_activated)
	vbox.add_child(tree_control)

# Scan who instantiates or inherits the active open scene
func _on_scan_btn_pressed() -> void:
	var tree_ctrl: Tree = find_child("UsageTree", true, false) as Tree
	if not tree_ctrl:
		return
		
	tree_ctrl.clear()
	
	var root_node: Node = editor_interface.get_edited_scene_root()
	if not root_node:
		printerr("[Usage Tracker] No active scene is open.")
		return
		
	var scene_path: String = root_node.scene_file_path
	if scene_path == "":
		printerr("[Usage Tracker] Current scene is unsaved. Please save first.")
		return
		
	var root_item: TreeItem = tree_ctrl.create_item()
	root_item.set_text(0, scene_path.get_file())
	var editor_base: Control = editor_interface.get_base_control()
	if editor_base:
		root_item.set_icon(0, editor_base.get_theme_icon("PackedScene", "EditorIcons"))
	
	# Get scene UID
	var scene_id: int = ResourceLoader.get_resource_uid(scene_path)
	var scene_uid: String = ResourceUID.id_to_text(scene_id)
	
	var instantiated_in: Array[String] = []
	var inherited_in: Array[String] = []
	
	_scan_project_scenes_for_dependencies(scene_path, scene_uid, instantiated_in, inherited_in)
	
	# Populate Instantiated In
	if not instantiated_in.is_empty():
		var inst_header: TreeItem = tree_ctrl.create_item(root_item)
		inst_header.set_text(0, "Instantiated In")
		inst_header.set_selectable(0, false)
		for path in instantiated_in:
			var item: TreeItem = tree_ctrl.create_item(inst_header)
			item.set_text(0, path)
			item.set_text(1, "Instance")
			item.set_metadata(0, path)
			if editor_base:
				item.set_icon(0, editor_base.get_theme_icon("PackedScene", "EditorIcons"))
				
	# Populate Inherited By
	if not inherited_in.is_empty():
		var inh_header: TreeItem = tree_ctrl.create_item(root_item)
		inh_header.set_text(0, "Inherited By")
		inh_header.set_selectable(0, false)
		for path in inherited_in:
			var item: TreeItem = tree_ctrl.create_item(inh_header)
			item.set_text(0, path)
			item.set_text(1, "Inheritance")
			item.set_metadata(0, path)
			if editor_base:
				item.set_icon(0, editor_base.get_theme_icon("PackedScene", "EditorIcons"))
				
	if instantiated_in.is_empty() and inherited_in.is_empty():
		var empty_item: TreeItem = tree_ctrl.create_item(root_item)
		empty_item.set_text(0, "No other scenes instantiate or inherit this scene.")
		empty_item.set_selectable(0, false)
		
	root_item.set_collapsed(false)

# Triggered when 'Clear List' is pressed
func _on_clear_btn_pressed() -> void:
	var tree_ctrl: Tree = find_child("UsageTree", true, false) as Tree
	if tree_ctrl:
		tree_ctrl.clear()

# Pop up help dialog instructions
func _on_help_btn_pressed() -> void:
	var dialog: AcceptDialog = AcceptDialog.new()
	dialog.title = "Scene Usage Instructions"
	dialog.dialog_text = "How to use this tool:\n\n" + \
		"1. Open any scene in the editor.\n\n" + \
		"2. Press 'Scan Active Scene' to search the entire project for files that instantiate or inherit from this active scene.\n\n" + \
		"3. Double-click any scene path in the list to automatically open it in the editor.\n\n" + \
		"4. Press 'Clear List' to empty the results table."
		
	editor_interface.get_base_control().add_child(dialog)
	dialog.popup_centered(Vector2(450, 280))
	dialog.visibility_changed.connect(func(): if not dialog.visible: dialog.queue_free())

# Handle double-click to open scene file
func _on_item_activated() -> void:
	var tree_ctrl: Tree = find_child("UsageTree", true, false) as Tree
	if not tree_ctrl:
		return
		
	var selected_item: TreeItem = tree_ctrl.get_selected()
	if selected_item:
		var scene_path = selected_item.get_metadata(0)
		if scene_path is String and scene_path != "":
			editor_interface.open_scene_from_path(scene_path)
			print("[Usage Tracker] Opened scene: ", scene_path)

# Scan all .tscn files in project to find dependencies
func _scan_project_scenes_for_dependencies(target_path: String, target_uid: String, instantiated: Array[String], inherited: Array[String]) -> void:
	_scan_dep_recursive("res://", target_path, target_uid, instantiated, inherited)
	
func _scan_dep_recursive(dir_path: String, target_path: String, target_uid: String, instantiated: Array[String], inherited: Array[String]) -> void:
	var path_lower: String = dir_path.to_lower()
	if "addon" in path_lower or ".godot" in path_lower:
		return
		
	var dir = DirAccess.open(dir_path)
	if dir:
		var files = dir.get_files()
		for file_name in files:
			if file_name.ends_with(".tscn"):
				var file_path = dir_path.path_join(file_name)
				if file_path == target_path:
					continue
				_check_dependencies_in_scene(file_path, target_path, target_uid, instantiated, inherited)
				
		var subdirs = dir.get_directories()
		for subdir_name in subdirs:
			_scan_dep_recursive(dir_path.path_join(subdir_name), target_path, target_uid, instantiated, inherited)

# Parse .tscn file as text to check relationship (Super robust, UID-based with Path Fallback)
func _check_dependencies_in_scene(file_path: String, target_path: String, target_uid: String, instantiated: Array[String], inherited: Array[String]) -> void:
	var file = FileAccess.open(file_path, FileAccess.READ)
	if not file:
		return
		
	var text = file.get_as_text()
	file.close()
	
	var text_lower: String = text.to_lower()
	var path_pos: int = -1
	
	if target_uid != "" and target_uid.to_lower() in text_lower:
		path_pos = text_lower.find(target_uid.to_lower())
	else:
		var search_str_lower: String = "path=\"%s\"" % target_path.to_lower()
		path_pos = text_lower.find(search_str_lower)
	
	if path_pos != -1:
		var bracket_start: int = text.rfind("[ext_resource", path_pos)
		var bracket_end: int = text.find("]", path_pos)
		if bracket_start != -1 and bracket_end != -1 and bracket_end > bracket_start:
			var ext_resource_line: String = text.substr(bracket_start, bracket_end - bracket_start)
			
			var ext_id: String = ""
			var id_idx: int = ext_resource_line.find(" id=")
			if id_idx != -1:
				var after_id: String = ext_resource_line.substr(id_idx + 4).strip_edges()
				if after_id.begins_with("\""):
					after_id = after_id.substr(1)
					var quote_end: int = after_id.find("\"")
					if quote_end != -1:
						ext_id = after_id.substr(0, quote_end)
				else:
					var end_pos = after_id.length()
					var space_pos = after_id.find(" ")
					var bracket_pos = after_id.find("]")
					if space_pos != -1:
						end_pos = min(end_pos, space_pos)
					if bracket_pos != -1:
						end_pos = min(end_pos, bracket_pos)
					ext_id = after_id.substr(0, end_pos).strip_edges()
					
			if ext_id != "":
				var instance_str_quotes: String = "instance=ExtResource(\"%s\")" % ext_id
				var instance_str_no_quotes: String = "instance=ExtResource(%s)" % ext_id
				
				if instance_str_quotes in text or instance_str_no_quotes in text:
					var first_node_line: String = ""
					var lines: PackedStringArray = text.split("\n")
					for line in lines:
						var clean: String = line.strip_edges()
						if clean.begins_with("[node"):
							first_node_line = clean
							break
							
					if instance_str_quotes in first_node_line or instance_str_no_quotes in first_node_line:
						if not file_path in inherited:
							inherited.append(file_path)
					else:
						if not file_path in instantiated:
							instantiated.append(file_path)

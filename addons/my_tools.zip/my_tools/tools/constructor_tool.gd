@tool
extends ScrollContainer

var editor_interface: EditorInterface

func _init() -> void:
	name = "Constructor"

func setup_tool(ei: EditorInterface) -> void:
	editor_interface = ei
	
	size_flags_horizontal = Control.SIZE_EXPAND_FILL
	size_flags_vertical = Control.SIZE_EXPAND_FILL
	
	var vbox: VBoxContainer = VBoxContainer.new()
	vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	vbox.size_flags_vertical = Control.SIZE_EXPAND_FILL
	add_child(vbox)
	
	# Title
	var title_label: Label = Label.new()
	title_label.text = "CONSTRUCTOR MANAGER (_INIT)"
	title_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(title_label)
	
	var hbox: HBoxContainer = HBoxContainer.new()
	vbox.add_child(hbox)
	
	# Button 1: Scan Project
	var scan_btn: Button = Button.new()
	scan_btn.text = "Scan Project"
	scan_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var editor_base: Control = editor_interface.get_base_control()
	if editor_base:
		scan_btn.icon = editor_base.get_theme_icon("Search", "EditorIcons")
	scan_btn.pressed.connect(_on_scan_btn_pressed)
	hbox.add_child(scan_btn)
	
	# Button 2: Generate at Caret
	var create_btn: Button = Button.new()
	create_btn.text = "Generate at Caret"
	create_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	if editor_base:
		create_btn.icon = editor_base.get_theme_icon("Add", "EditorIcons")
	create_btn.pressed.connect(_on_create_btn_pressed)
	hbox.add_child(create_btn)
	
	# Button 3: Help
	var help_btn: Button = Button.new()
	help_btn.text = "Help"
	help_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	if editor_base:
		help_btn.icon = editor_base.get_theme_icon("Help", "EditorIcons")
	help_btn.pressed.connect(_on_help_btn_pressed)
	hbox.add_child(help_btn)
	
	# Tree table to display results
	var tree_control: Tree = Tree.new()
	tree_control.name = "CtorTree"
	tree_control.columns = 3
	tree_control.column_titles_visible = true
	tree_control.set_column_title(0, "File")
	tree_control.set_column_title(1, "Class / Scope")
	tree_control.set_column_title(2, "Constructor Status")
	
	# Auto-balanced column layout
	tree_control.set_column_expand(0, true)
	tree_control.set_column_expand(1, true)
	tree_control.set_column_expand(2, true)
	tree_control.set_column_clip_content(0, true)
	tree_control.set_column_clip_content(1, true)
	tree_control.set_column_clip_content(2, true)
	tree_control.set_column_custom_minimum_width(0, 100)
	tree_control.set_column_custom_minimum_width(1, 110)
	tree_control.set_column_custom_minimum_width(2, 150)
	
	tree_control.size_flags_vertical = Control.SIZE_EXPAND_FILL
	
	# Double click item to jump to code
	tree_control.item_activated.connect(_on_item_activated)
	vbox.add_child(tree_control)

func _on_scan_btn_pressed() -> void:
	var tree_ctrl: Tree = find_child("CtorTree", true, false) as Tree
	if not tree_ctrl:
		return
		
	tree_ctrl.clear()
	var root_item: TreeItem = tree_ctrl.create_item()
	root_item.set_text(0, "Project")
	
	_scan_scripts_recursive("res://", root_item)
	root_item.set_collapsed(false)

func _on_create_btn_pressed() -> void:
	_generate_constructor_for_current()

# Pop up a clean native AcceptDialog containing the instructions when 'Help' is clicked
func _on_help_btn_pressed() -> void:
	var dialog: AcceptDialog = AcceptDialog.new()
	dialog.title = "Constructor Tool Instructions"
	dialog.dialog_text = "How to use this tool:\n\n" + \
		"1. Press 'Scan Project' to find Inner Classes or RefCounted/Resource scripts that lack or have incomplete _init() constructors.\n\n" + \
		"2. Double-click any result to open the script and navigate to that specific class scope.\n\n" + \
		"3. Place your caret inside an Inner Class or RefCounted/Resource scope, and click 'Generate at Caret' to auto-generate the _init() constructor.\n\n" + \
		"* Note:\n- You can press Ctrl+Z (or Cmd+Z on Mac) inside the Script Editor to completely undo or redo any generated constructors at once!"
	
	# Add to editor base control to apply the native dark theme properly
	editor_interface.get_base_control().add_child(dialog)
	dialog.popup_centered(Vector2(450, 300))
	
	# Safely free the dialog from memory when closed
	dialog.visibility_changed.connect(func(): if not dialog.visible: dialog.queue_free())

func _on_item_activated() -> void:
	var tree_ctrl: Tree = find_child("CtorTree", true, false) as Tree
	if not tree_ctrl:
		return
		
	var selected_item: TreeItem = tree_ctrl.get_selected()
	if selected_item:
		var file_path = selected_item.get_metadata(0)
		var line_num = selected_item.get_metadata(1)
		
		if file_path is String and file_path != "":
			var script_res: Script = load(file_path) as Script
			if script_res:
				var line: int = line_num if line_num is int else 1
				editor_interface.edit_script(script_res, line)

# Recursive directory scanning
func _scan_scripts_recursive(path: String, root_item: TreeItem) -> void:
	var path_lower: String = path.to_lower()
	if "addon" in path_lower or ".godot" in path_lower:
		return
		
	var dir: DirAccess = DirAccess.open(path)
	if dir:
		var files: PackedStringArray = dir.get_files()
		for file_name: String in files:
			if file_name.ends_with(".gd"):
				var file_path: String = path.path_join(file_name)
				_check_script_for_ctor_issues(file_path, root_item)
				
		var subdirs: PackedStringArray = dir.get_directories()
		for subdir_name: String in subdirs:
			var subdir_path: String = path.path_join(subdir_name)
			_scan_scripts_recursive(subdir_path, root_item)

# Get indentation length
func _get_indent_len(line: String) -> int:
	var length: int = 0
	for c in line:
		if c == " " or c == "\t":
			length += 1
		else:
			break
	return length

# --- HIGH-PRECISION INDEPENDENT CLASS/SCOPE PARSING ALGORITHM ---
func _parse_classes_from_file_lines(lines: PackedStringArray, extends_direct: bool) -> Array[Dictionary]:
	var scopes: Array[Dictionary] = []
	
	# 1. Collect declared classes (includes main class if extends is matched, and Inner Classes)
	if extends_direct:
		scopes.append({
			"name": "[Main Class]",
			"line": 1,
			"start_line": 0,
			"end_line": lines.size(),
			"body_indent_len": 0,
			"variables": [],
			"has_init": false,
			"init_params_count": 0
		})
		
	for idx in range(lines.size()):
		var line: String = lines[idx]
		var clean_line: String = line.strip_edges()
		if clean_line.begins_with("class ") and clean_line.ends_with(":"):
			var name_end: int = clean_line.find(":")
			var parsed_class_name: String = clean_line.substr(6, name_end - 6).strip_edges()
			var class_decl_line: int = idx
			var class_indent_len: int = _get_indent_len(line)
			
			# Find the end line of the Inner Class (the first line with indentation <= class declaration's indentation)
			var end_line: int = lines.size()
			for j in range(class_decl_line + 1, lines.size()):
				var l = lines[j]
				var cl = l.strip_edges()
				if cl == "" or cl.begins_with("#"):
					continue
				var l_indent_len = _get_indent_len(l)
				if l_indent_len <= class_indent_len:
					end_line = j
					break
					
			scopes.append({
				"name": "class " + parsed_class_name,
				"line": class_decl_line + 1,
				"start_line": class_decl_line + 1,
				"end_line": end_line,
				"body_indent_len": class_indent_len + 1, # Indentation of variables inside inner class (usually indented by 1 extra tab)
				"variables": [],
				"has_init": false,
				"init_params_count": 0
			})
			
	# 2. Scan variables and constructors in each scope
	for scope in scopes:
		var start: int = scope["start_line"]
		var end: int = scope["end_line"]
		var body_indent_len: int = scope["body_indent_len"]
		var inside_func: bool = false
		
		for i in range(start, end):
			var line: String = lines[i]
			var line_indent_len: int = _get_indent_len(line)
			var clean_line: String = line.strip_edges()
			
			if clean_line == "" or clean_line.begins_with("#"):
				continue
				
			# Check if we are currently inside a function
			if inside_func:
				# Exit function if current line indentation <= function indentation (sibling/parent level)
				if line_indent_len <= body_indent_len:
					inside_func = false
					
			if not inside_func:
				# Detect start of a new function
				if clean_line.begins_with("func ") and line_indent_len == body_indent_len:
					inside_func = true
					
					# If it is the _init function
					if clean_line.begins_with("func _init"):
						scope["has_init"] = true
						var start_paren: int = clean_line.find("(")
						var end_paren: int = clean_line.find(")")
						if start_paren != -1 and end_paren != -1 and end_paren > start_paren:
							var params_str: String = clean_line.substr(start_paren + 1, end_paren - (start_paren + 1)).strip_edges()
							if params_str != "":
								scope["init_params_count"] = params_str.split(",").size()
					continue
					
				# Scan variables located at class body level
				if line_indent_len == body_indent_len and "var " in clean_line:
					var is_export: bool = "@export" in clean_line
					var is_onready: bool = "@onready" in clean_line
					
					if not is_export and not is_onready:
						var var_pos: int = clean_line.find("var ")
						var after_var: String = clean_line.substr(var_pos + 4).strip_edges()
						var colon_pos: int = after_var.find(":")
						var eq_pos: int = after_var.find("=")
						var split_pos: int = -1
						
						if colon_pos != -1 and eq_pos != -1:
							split_pos = min(colon_pos, eq_pos)
						elif colon_pos != -1:
							split_pos = colon_pos
						elif eq_pos != -1:
							split_pos = eq_pos
							
						var var_name: String = ""
						var var_type: String = ""
						if split_pos != -1:
							var_name = after_var.substr(0, split_pos).strip_edges()
							var_type = after_var.substr(split_pos + 1).strip_edges()
							# FIX ATTACHED COMMENT: Strip "#" from the data type
							if "#" in var_type:
								var_type = var_type.split("#")[0].strip_edges()
						else:
							var raw_name = after_var.split(" ")[0].strip_edges()
							# FIX ATTACHED COMMENT: Strip "#" from the variable name
							if "#" in raw_name:
								raw_name = raw_name.split("#")[0].strip_edges()
							var_name = raw_name
							
						if var_name != "":
							scope["variables"].append({"name": var_name, "type": var_type})
							
	return scopes

# Parse script contents for missing/incomplete constructors
func _check_script_for_ctor_issues(file_path: String, root_item: TreeItem) -> void:
	var file: FileAccess = FileAccess.open(file_path, FileAccess.READ)
	if not file:
		return
		
	var lines: PackedStringArray = []
	while file.get_position() < file.get_length():
		lines.append(file.get_line())
	file.close()
	
	# Check if the main class directly extends Resource or RefCounted
	var extends_direct_resource_or_refcounted: bool = false
	for line in lines:
		var clean_line: String = line.strip_edges()
		if clean_line.begins_with("extends "):
			var base_type: String = clean_line.substr(8).strip_edges()
			if "#" in base_type:
				base_type = base_type.split("#")[0].strip_edges()
			if base_type == "Resource" or base_type == "RefCounted" or base_type == "RefCount":
				extends_direct_resource_or_refcounted = true
				break
				
	# Analyze scopes using the unified scoping parser
	var scopes: Array[Dictionary] = _parse_classes_from_file_lines(lines, extends_direct_resource_or_refcounted)

	var tree_ctrl: Tree = find_child("CtorTree", true, false) as Tree
	if not tree_ctrl:
		return
		
	for scope in scopes:
		var var_count: int = scope["variables"].size()
		var has_ctor: bool = scope["has_init"]
		var ctor_params: int = scope["init_params_count"]
		
		# Rule 3: Only report issues if there is at least 1 ordinary variable
		if var_count > 0:
			var is_incomplete: bool = false
			var status_msg: String = ""
			
			if not has_ctor:
				is_incomplete = true
				status_msg = "Missing _init() (Needs %d params)" % var_count
			elif ctor_params != var_count:
				is_incomplete = true
				status_msg = "Incomplete (Assigned %d/%d variables)" % [ctor_params, var_count]
				
			if is_incomplete:
				var item: TreeItem = tree_ctrl.create_item(root_item)
				item.set_text(0, file_path.get_file())
				item.set_text(1, scope["name"])
				item.set_text(2, status_msg)
				item.set_metadata(0, file_path)
				item.set_metadata(1, scope["line"])

# Generate constructor for the current caret scope
func _generate_constructor_for_current() -> void:
	var script_editor: ScriptEditor = editor_interface.get_script_editor()
	if not script_editor: return
	var current_editor = script_editor.get_current_editor()
	if not current_editor: return
	var code_edit: CodeEdit = current_editor.get_base_editor() as CodeEdit
	if not code_edit: return
	
	var current_script: Script = script_editor.get_current_script()
	if not current_script: return
	
	var current_line: int = code_edit.get_caret_line()
	
	# 1. Read all lines of the currently open file
	var lines: PackedStringArray = []
	for i in range(code_edit.get_line_count()):
		lines.append(code_edit.get_line(i))
		
	# 2. Check if the main script inherits from Node (to show safety warning at indentation 0)
	var is_node_script: bool = false
	var base_type: String = current_script.get_instance_base_type()
	if ClassDB.class_exists(base_type) and ClassDB.is_parent_class(base_type, "Node"):
		is_node_script = true
		
	# Get indentation of the current caret line
	var current_line_text: String = code_edit.get_line(current_line)
	var indent: String = ""
	for c in current_line_text:
		if c == " " or c == "\t":
			indent += c
		else:
			break
			
	var is_inside_inner_class: bool = indent.length() > 0
	
	if is_node_script and not is_inside_inner_class:
		var dialog: AcceptDialog = AcceptDialog.new()
		dialog.title = "Godot Architecture Warning"
		dialog.dialog_text = "Defining parameterized _init() constructors is NOT recommended for main scripts inheriting from Node (this causes crashes when Godot instantiates the Scene).\n\nPlease place your caret inside an Inner Class (nested class) or use this tool on standalone RefCounted/Resource scripts."
		editor_interface.get_base_control().add_child(dialog)
		dialog.popup_centered()
		dialog.visibility_changed.connect(func(): if not dialog.visible: dialog.queue_free())
		return
		
	# 3. Analyze scopes in the file using the precise parsing algorithm
	var scopes: Array[Dictionary] = _parse_classes_from_file_lines(lines, true)
	
	# 4. Find the correct scope containing the current caret line
	var target_scope: Dictionary = {}
	for scope in scopes:
		if current_line >= scope["start_line"] and current_line <= scope["end_line"]:
			target_scope = scope
			
	if target_scope.is_empty():
		print("[Ctor Generator] Error: No valid class scope found at caret.")
		return
		
	var variables: Array = target_scope["variables"]
	
	# 5. Build _init() constructor source code string
	var ctor_lines: Array[String] = []
	var params_array: Array[String] = []
	for v in variables:
		var param_str: String = "p_" + v["name"]
		if v["type"] != "":
			param_str += ": " + v["type"]
		params_array.append(param_str)
		
	var params_joined: String = ", ".join(params_array)
	ctor_lines.append(indent + "func _init(%s) -> void:" % params_joined)
	
	if variables.is_empty():
		ctor_lines.append(indent + "\tpass")
	else:
		for v in variables:
			ctor_lines.append(indent + "\t%s = p_%s" % [v["name"], v["name"]])
			
	# 6. Insert the source code at the current caret line
	# Wrap constructor generation under a single complex operation to support full Ctrl+Z
	code_edit.begin_complex_operation()
	for i in range(ctor_lines.size()):
		code_edit.insert_line_at(current_line + i, ctor_lines[i])
	code_edit.end_complex_operation()
		
	code_edit.set_caret_line(current_line + ctor_lines.size())
	
	# Update source code (reuse the current_script variable declared at the start of the function)
	if current_script:
		current_script.source_code = code_edit.text
		ResourceSaver.save(current_script, current_script.resource_path)
		# Clear the unsaved asterisk (*) in the Editor's UI
		code_edit.tag_saved_version()
		
	if script_editor.has_method("save_all_scripts"):
		script_editor.call("save_all_scripts")
		
	_on_scan_btn_pressed()
